import React, { createContext, useContext, useState, useEffect } from 'react'
import { toast } from 'react-toastify'

const CartContext = createContext(null)

export const useCart = () => {
  const context = useContext(CartContext)
  if (!context) throw new Error('useCart must be used within CartProvider')
  return context
}

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([])

  useEffect(() => {
    const savedCart = localStorage.getItem('marketplace_cart')
    if (savedCart) setCartItems(JSON.parse(savedCart))
  }, [])

  const saveCart = (items) => {
    setCartItems(items)
    localStorage.setItem('marketplace_cart', JSON.stringify(items))
  }

  const addToCart = (product, quantity = 1) => {
    const existingItem = cartItems.find(item => item.id === product.id)
    if (existingItem) {
      const newQuantity = existingItem.quantity + quantity
      if (newQuantity > product.stock_quantity) { toast.warning('Not enough stock available'); return }
      saveCart(cartItems.map(item => item.id === product.id ? { ...item, quantity: newQuantity } : item))
      toast.success('Cart updated')
    } else {
      if (quantity > product.stock_quantity) { toast.warning('Not enough stock available'); return }
      saveCart([...cartItems, { id: product.id, name: product.name, price: product.price, image: product.image_urls?.[0], vendor_id: product.vendor_id, vendor_name: product.vendor?.store_name, quantity, max_stock: product.stock_quantity }])
      toast.success('Added to cart')
    }
  }

  const removeFromCart = (productId) => { saveCart(cartItems.filter(item => item.id !== productId)); toast.info('Removed from cart') }
  const updateQuantity = (productId, quantity) => {
    if (quantity < 1) return
    const item = cartItems.find(item => item.id === productId)
    if (!item || quantity > item.max_stock) { toast.warning('Not enough stock available'); return }
    saveCart(cartItems.map(item => item.id === productId ? { ...item, quantity } : item))
  }
  const clearCart = () => saveCart([])
  const getCartTotal = () => cartItems.reduce((total, item) => total + (item.price * item.quantity), 0)
  const getCartCount = () => cartItems.reduce((count, item) => count + item.quantity, 0)
  const getItemsByVendor = () => {
    const vendorMap = {}
    cartItems.forEach(item => {
      if (!vendorMap[item.vendor_id]) vendorMap[item.vendor_id] = { vendor_id: item.vendor_id, vendor_name: item.vendor_name, items: [] }
      vendorMap[item.vendor_id].items.push(item)
    })
    return Object.values(vendorMap)
  }

  return <CartContext.Provider value={{ cartItems, addToCart, removeFromCart, updateQuantity, clearCart, getCartTotal, getCartCount, getItemsByVendor }}>{children}</CartContext.Provider>
}
