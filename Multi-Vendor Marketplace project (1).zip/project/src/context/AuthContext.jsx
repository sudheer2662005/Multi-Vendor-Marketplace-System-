import React, { createContext, useContext, useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

const AuthContext = createContext(null)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used within AuthProvider')
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [userType, setUserType] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const savedUser = localStorage.getItem('marketplace_user')
    const savedUserType = localStorage.getItem('marketplace_user_type')
    if (savedUser && savedUserType) {
      setUser(JSON.parse(savedUser))
      setUserType(savedUserType)
    }
    setLoading(false)
  }, [])

  const loginAdmin = async (email, password) => {
    const { data, error } = await supabase.from('admins').select('*').eq('email', email).eq('password_hash', password).single()
    if (error) throw new Error('Invalid credentials')
    setUser(data); setUserType('admin')
    localStorage.setItem('marketplace_user', JSON.stringify(data))
    localStorage.setItem('marketplace_user_type', 'admin')
    return data
  }

  const loginVendor = async (email, password) => {
    const { data, error } = await supabase.from('vendors').select('*').eq('email', email).eq('password_hash', password).single()
    if (error) throw new Error('Invalid credentials')
    if (data.status !== 'approved') throw new Error('Your account is pending approval')
    setUser(data); setUserType('vendor')
    localStorage.setItem('marketplace_user', JSON.stringify(data))
    localStorage.setItem('marketplace_user_type', 'vendor')
    return data
  }

  const loginCustomer = async (email, password) => {
    const { data, error } = await supabase.from('customers').select('*').eq('email', email).eq('password_hash', password).single()
    if (error) throw new Error('Invalid credentials')
    setUser(data); setUserType('customer')
    localStorage.setItem('marketplace_user', JSON.stringify(data))
    localStorage.setItem('marketplace_user_type', 'customer')
    return data
  }

  const registerVendor = async (vendorData) => {
    const { data, error } = await supabase.from('vendors').insert([{ email: vendorData.email, password_hash: vendorData.password, store_name: vendorData.storeName, owner_name: vendorData.ownerName, phone: vendorData.phone, address: vendorData.address, status: 'pending' }]).select().single()
    if (error) throw error
    return data
  }

  const registerCustomer = async (customerData) => {
    const { data, error } = await supabase.from('customers').insert([{ email: customerData.email, password_hash: customerData.password, full_name: customerData.fullName, phone: customerData.phone, address: customerData.address, city: customerData.city, postal_code: customerData.postalCode }]).select().single()
    if (error) throw error
    return data
  }

  const logout = () => {
    setUser(null); setUserType(null)
    localStorage.removeItem('marketplace_user')
    localStorage.removeItem('marketplace_user_type')
  }

  const updateCustomerProfile = async (updates) => {
    const { data, error } = await supabase.from('customers').update(updates).eq('id', user.id).select().single()
    if (error) throw error
    setUser(data)
    localStorage.setItem('marketplace_user', JSON.stringify(data))
    return data
  }

  return <AuthContext.Provider value={{ user, userType, loading, loginAdmin, loginVendor, loginCustomer, registerVendor, registerCustomer, logout, updateCustomerProfile }}>{children}</AuthContext.Provider>
}
