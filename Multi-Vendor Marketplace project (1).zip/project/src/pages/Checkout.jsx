import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'
import { toast } from 'react-toastify'
import Navbar from '../components/Navbar'
import OptImage from '../components/OptImage'

const Checkout = () => {
  const { cartItems, getCartTotal, getItemsByVendor, clearCart } = useCart()
  const { user } = useAuth()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState('cod')
  const [shippingInfo, setShippingInfo] = useState({ address: user?.address || '', city: user?.city || '', postal_code: user?.postal_code || '', phone: user?.phone || '' })
  const vendorGroups = getItemsByVendor()

  const handleChange = (e) => setShippingInfo({ ...shippingInfo, [e.target.name]: e.target.value })

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (cartItems.length === 0) { toast.error('Your cart is empty'); return }
    if (!shippingInfo.address || !shippingInfo.city) { toast.error('Please fill in shipping address'); return }
    setLoading(true)

    try {
      const totalAmount = getCartTotal()
      let totalCommission = 0
      const orderItemsData = []

      for (const item of cartItems) {
        const { data: vendorData } = await supabase.from('vendors').select('commission_rate').eq('id', item.vendor_id).single()
        const commissionRate = vendorData?.commission_rate || 10
        const itemTotal = item.price * item.quantity
        const commission = (itemTotal * commissionRate) / 100
        const vendorEarning = itemTotal - commission
        totalCommission += commission
        orderItemsData.push({ product_id: item.id, vendor_id: item.vendor_id, quantity: item.quantity, unit_price: item.price, commission_rate: commissionRate, vendor_earning: vendorEarning, status: 'pending' })
      }

      const { data: order, error: orderError } = await supabase.from('orders').insert([{
        customer_id: user.id, total_amount: totalAmount, total_commission: totalCommission, status: 'pending',
        shipping_address: `${shippingInfo.address}, ${shippingInfo.city} ${shippingInfo.postal_code}`,
        payment_method: paymentMethod, payment_status: paymentMethod === 'cod' ? 'pending' : 'paid'
      }]).select().single()

      if (orderError) throw orderError

      const orderItemsWithOrderId = orderItemsData.map(item => ({ ...item, order_id: order.id }))
      const { error: itemsError } = await supabase.from('order_items').insert(orderItemsWithOrderId)
      if (itemsError) throw itemsError

      await supabase.from('payments').insert([{
        order_id: order.id, payment_method: paymentMethod, amount: totalAmount,
        transaction_id: paymentMethod !== 'cod' ? `SIM_${Date.now()}` : null,
        status: paymentMethod === 'cod' ? 'pending' : 'completed'
      }])

      for (const item of cartItems) {
        await supabase.rpc('decrement_stock', { product_id: item.id, qty: item.quantity })
      }

      clearCart()
      toast.success('Order placed successfully!')
      navigate(`/order-success/${order.id}`)
    } catch (error) { console.error('Checkout error:', error); toast.error('Failed to place order') }
    finally { setLoading(false) }
  }

  if (cartItems.length === 0) return <><Navbar /><div className="container py-5"><div className="empty-state"><i className="bi bi-cart3"></i><h4>Your cart is empty</h4></div></div></>

  return (
    <>
      <Navbar />
      <div className="container py-4">
        <h2 className="mb-4">Checkout</h2>
        <form onSubmit={handleSubmit}>
          <div className="row g-4">
            <div className="col-lg-8">
              <div className="card mb-4">
                <div className="card-body">
                  <h5 className="card-title mb-3"><i className="bi bi-geo-alt me-2"></i>Shipping Address</h5>
                  <div className="row g-3">
                    <div className="col-12"><label className="form-label">Street Address *</label><input type="text" className="form-control" name="address" value={shippingInfo.address} onChange={handleChange} required /></div>
                    <div className="col-md-6"><label className="form-label">City *</label><input type="text" className="form-control" name="city" value={shippingInfo.city} onChange={handleChange} required /></div>
                    <div className="col-md-6"><label className="form-label">Postal Code</label><input type="text" className="form-control" name="postal_code" value={shippingInfo.postal_code} onChange={handleChange} /></div>
                    <div className="col-12"><label className="form-label">Phone Number *</label><input type="tel" className="form-control" name="phone" value={shippingInfo.phone} onChange={handleChange} required /></div>
                  </div>
                </div>
              </div>

              <div className="card mb-4">
                <div className="card-body">
                  <h5 className="card-title mb-3"><i className="bi bi-credit-card me-2"></i>Payment Method</h5>
                  <div className="row g-3">
                    {[['upi', 'phone'], ['card', 'credit-card'], ['netbanking', 'bank'], ['cod', 'cash']].map(([method, icon]) => (
                      <div key={method} className="col-md-3 col-6">
                        <div className={`card h-100 ${paymentMethod === method ? 'border-primary' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setPaymentMethod(method)}>
                          <div className="card-body text-center">
                            <i className={`bi bi-${icon} fs-1 d-block mb-2 text-primary`}></i>
                            <h6>{method === 'upi' ? 'UPI' : method === 'cod' ? 'Cash on Delivery' : method === 'card' ? 'Card' : 'Net Banking'}</h6>
                            {paymentMethod === method && <i className="bi bi-check-circle text-success"></i>}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {paymentMethod === 'upi' && (
                    <div className="mt-4 p-4 bg-light rounded text-center">
                      <h6 className="mb-3">Scan QR Code to Pay</h6>
                      <div className="d-flex justify-content-center mb-3">
                        <img
                          src="/AccountQRCodeState_Bank_of_India_-_9256_LIGHT_THEME.png"
                          alt="UPI QR Code"
                          style={{ width: 220, height: 220, borderRadius: 12, border: '3px solid #fff', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}
                        />
                      </div>
                      <div className="mb-2"><strong>UPI ID:</strong> <span className="text-primary fw-bold">9550897804@ibl</span></div>
                      <div className="text-muted small">Amount: ₹{getCartTotal().toFixed(2)}</div>
                      <div className="alert alert-info mt-3 py-2 small">
                        <i className="bi bi-info-circle me-2"></i>
                        Scan with any UPI app (GPay, PhonePe, Paytm, BHIM). Order will be confirmed after payment.
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'card' && (
                    <div className="mt-4 p-4 bg-light rounded">
                      <div className="row g-3">
                        <div className="col-12">
                          <label className="form-label">Card Number</label>
                          <input type="text" className="form-control" placeholder="1234 5678 9012 3456" maxLength="19" />
                        </div>
                        <div className="col-md-6">
                          <label className="form-label">Expiry Date</label>
                          <input type="text" className="form-control" placeholder="MM/YY" maxLength="5" />
                        </div>
                        <div className="col-md-6">
                          <label className="form-label">CVV</label>
                          <input type="password" className="form-control" placeholder="***" maxLength="3" />
                        </div>
                        <div className="col-12">
                          <label className="form-label">Name on Card</label>
                          <input type="text" className="form-control" placeholder="John Doe" />
                        </div>
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'netbanking' && (
                    <div className="mt-4 p-4 bg-light rounded">
                      <label className="form-label">Select Your Bank</label>
                      <select className="form-select">
                        <option value="">Choose a bank</option>
                        <option value="sbi">State Bank of India</option>
                        <option value="hdfc">HDFC Bank</option>
                        <option value="icici">ICICI Bank</option>
                        <option value="axis">Axis Bank</option>
                        <option value="kotak">Kotak Mahindra Bank</option>
                        <option value="pnb">Punjab National Bank</option>
                        <option value="bob">Bank of Baroda</option>
                        <option value="idbi">IDBI Bank</option>
                      </select>
                    </div>
                  )}
                </div>
              </div>

              <div className="card">
                <div className="card-body">
                  <h5 className="card-title mb-3"><i className="bi bi-bag me-2"></i>Order Items</h5>
                  {cartItems.map(item => <div key={item.id} className="d-flex align-items-center gap-3 py-2 border-bottom"><OptImage src={item.image} alt={item.name} style={{ width: 60, height: 60, objectFit: 'cover', borderRadius: 8, flexShrink: 0 }} /><div className="flex-grow-1"><h6 className="mb-0">{item.name}</h6><small className="text-muted">{item.vendor_name} • Qty: {item.quantity}</small></div><strong>₹{(item.price * item.quantity).toFixed(2)}</strong></div>)}
                </div>
              </div>
            </div>

            <div className="col-lg-4">
              <div className="card sticky-top" style={{ top: '20px' }}>
                <div className="card-body">
                  <h5 className="card-title mb-4">Order Summary</h5>
                  {vendorGroups.map(group => (<div key={group.vendor_id} className="mb-3"><small className="text-muted d-block mb-1">{group.vendor_name}</small>{group.items.map(item => <div key={item.id} className="d-flex justify-content-between"><span>{item.name} x{item.quantity}</span><span>₹{(item.price * item.quantity).toFixed(2)}</span></div>)}</div>))}
                  <hr />
                  <div className="d-flex justify-content-between mb-2"><span>Subtotal</span><span>₹{getCartTotal().toFixed(2)}</span></div>
                  <div className="d-flex justify-content-between mb-2"><span>Shipping</span><span className="text-success">Free</span></div>
                  <hr />
                  <div className="d-flex justify-content-between mb-4"><strong>Total</strong><strong className="fs-5 text-primary">₹{getCartTotal().toFixed(2)}</strong></div>
                  <button type="submit" className="btn btn-primary w-100 btn-lg" disabled={loading}>{loading ? <><span className="spinner-border spinner-border-sm me-2"></span>Processing...</> : paymentMethod === 'cod' ? 'Place Order' : 'Pay Now'}</button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </>
  )
}

export default Checkout
