import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'
import Navbar from '../components/Navbar'
import OptImage from '../components/OptImage'

const Cart = () => {
  const { cartItems, removeFromCart, updateQuantity, getCartTotal, getItemsByVendor } = useCart()
  const { user, userType } = useAuth()
  const navigate = useNavigate()
  const vendorGroups = getItemsByVendor()

  const handleCheckout = () => {
    if (!user) { navigate('/login'); return }
    if (userType !== 'customer') { alert('Please login as a customer to checkout'); return }
    navigate('/checkout')
  }

  if (cartItems.length === 0) {
    return <><Navbar /><div className="container py-5"><div className="empty-state"><i className="bi bi-cart3"></i><h4>Your cart is empty</h4><p className="text-muted">Looks like you haven't added anything yet</p><Link to="/products" className="btn btn-primary mt-3"><i className="bi bi-arrow-left me-2"></i>Continue Shopping</Link></div></div></>
  }

  return (
    <>
      <Navbar />
      <div className="container py-4">
        <h2 className="mb-4">Shopping Cart</h2>
        <div className="row g-4">
          <div className="col-lg-8">
            {vendorGroups.map(group => (
              <div key={group.vendor_id} className="card mb-3">
                <div className="card-header bg-white"><div className="d-flex align-items-center gap-2"><i className="bi bi-shop"></i><strong>{group.vendor_name}</strong></div></div>
                <div className="card-body">
                  {group.items.map(item => (
                    <div key={item.id} className="cart-item border-bottom pb-3 mb-3">
                      <OptImage src={item.image} alt={item.name} style={{ width: '80px', height: '80px', objectFit: 'cover', borderRadius: '8px', flexShrink: 0 }} />
                      <div className="flex-grow-1"><Link to={`/product/${item.id}`}><h6 className="mb-1 text-dark">{item.name}</h6></Link><p className="text-muted mb-2 small">₹{item.price.toFixed(2)} each</p></div>
                      <div className="text-end">
                        <div className="d-flex align-items-center gap-2 mb-2">
                          <button className="btn btn-sm btn-outline-secondary" onClick={() => updateQuantity(item.id, item.quantity - 1)} disabled={item.quantity <= 1}><i className="bi bi-dash"></i></button>
                          <span className="px-2 fw-semibold">{item.quantity}</span>
                          <button className="btn btn-sm btn-outline-secondary" onClick={() => updateQuantity(item.id, item.quantity + 1)} disabled={item.quantity >= item.max_stock}><i className="bi bi-plus"></i></button>
                        </div>
                        <button className="btn btn-sm btn-link text-danger" onClick={() => removeFromCart(item.id)}><i className="bi bi-trash me-1"></i>Remove</button>
                      </div>
                      <div className="ms-3"><strong>₹{(item.price * item.quantity).toFixed(2)}</strong></div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
            <Link to="/products" className="btn btn-outline-primary"><i className="bi bi-arrow-left me-2"></i>Continue Shopping</Link>
          </div>
          <div className="col-lg-4">
            <div className="card sticky-top" style={{ top: '20px' }}>
              <div className="card-body">
                <h5 className="card-title mb-4">Order Summary</h5>
                <div className="d-flex justify-content-between mb-2"><span>Subtotal ({cartItems.length} items)</span><span>₹{getCartTotal().toFixed(2)}</span></div>
                <div className="d-flex justify-content-between mb-2"><span>Shipping</span><span className="text-success">Free</span></div>
                <hr />
                <div className="d-flex justify-content-between mb-4"><strong>Total</strong><strong className="fs-5 text-primary">₹{getCartTotal().toFixed(2)}</strong></div>
                <button className="btn btn-primary w-100 btn-lg" onClick={handleCheckout}>Proceed to Checkout</button>
                {!user && <p className="text-center text-muted mt-3 small">You'll need to login as a customer to complete your purchase</p>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default Cart
