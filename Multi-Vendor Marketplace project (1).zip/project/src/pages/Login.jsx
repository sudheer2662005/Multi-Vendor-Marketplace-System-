import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { toast } from 'react-toastify'

const Login = () => {
  const [userType, setUserType] = useState('customer')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const { loginAdmin, loginVendor, loginCustomer } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      if (userType === 'admin') { await loginAdmin(email, password); navigate('/admin') }
      else if (userType === 'vendor') { await loginVendor(email, password); navigate('/vendor') }
      else { await loginCustomer(email, password); navigate('/customer') }
      toast.success('Login successful!')
    } catch (error) { toast.error(error.message || 'Login failed') }
    finally { setLoading(false) }
  }

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="text-center mb-4">
          <Link to="/" className="text-decoration-none"><h2 className="d-flex align-items-center justify-content-center gap-2"><i className="bi bi-shop text-primary"></i>Marketplace</h2></Link>
          <p className="text-muted">Sign in to your account</p>
        </div>
        <div className="d-flex justify-content-center mb-4">
          <div className="btn-group" role="group">
            <button type="button" className={`btn ${userType === 'customer' ? 'btn-primary' : 'btn-outline-primary'}`} onClick={() => setUserType('customer')}><i className="bi bi-person me-1"></i>Customer</button>
            <button type="button" className={`btn ${userType === 'vendor' ? 'btn-primary' : 'btn-outline-primary'}`} onClick={() => setUserType('vendor')}><i className="bi bi-shop-window me-1"></i>Vendor</button>
            <button type="button" className={`btn ${userType === 'admin' ? 'btn-primary' : 'btn-outline-primary'}`} onClick={() => setUserType('admin')}><i className="bi bi-gear me-1"></i>Admin</button>
          </div>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label">Email Address</label>
            <div className="input-group"><span className="input-group-text"><i className="bi bi-envelope"></i></span><input type="email" className="form-control" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Enter your email" required /></div>
          </div>
          <div className="mb-4">
            <label className="form-label">Password</label>
            <div className="input-group"><span className="input-group-text"><i className="bi bi-lock"></i></span><input type="password" className="form-control" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" required /></div>
          </div>
          <button type="submit" className="btn btn-primary w-100" disabled={loading}>{loading ? <><span className="spinner-border spinner-border-sm me-2"></span>Signing in...</> : 'Sign In'}</button>
        </form>
        <div className="text-center mt-4">{userType !== 'admin' && <p className="text-muted">Don't have an account? <Link to="/register">Sign up</Link></p>}</div>
        <hr className="my-4" />
        <div className="text-center">
          <p className="text-muted mb-2">Demo Credentials:</p>
          <small className="text-muted d-block">Admin: admin@marketplace.com / admin123</small>
          <small className="text-muted d-block">Vendor: techstore@example.com / vendor123</small>
          <small className="text-muted d-block">Customer: john.customer@example.com / customer123</small>
        </div>
      </div>
    </div>
  )
}

export default Login
