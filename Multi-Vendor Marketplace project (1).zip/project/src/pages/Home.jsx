import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import Navbar from '../components/Navbar'
import OptImage from '../components/OptImage'
import { useCart } from '../context/CartContext'

const Home = () => {
  const [categories, setCategories] = useState([])
  const [featuredProducts, setFeaturedProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const { addToCart } = useCart()

  useEffect(() => { fetchData() }, [])

  const fetchData = async () => {
    try {
      const [catRes, prodRes] = await Promise.all([
        supabase.from('categories').select('*').eq('is_active', true),
        supabase.from('products').select('*, vendor:vendor_id(store_name)').eq('is_active', true).limit(12)
      ])
      setCategories(catRes.data || [])
      setFeaturedProducts(prodRes.data || [])
    } catch (error) { console.error('Error:', error) }
    finally { setLoading(false) }
  }

  const handleAddToCart = (e, product) => { e.preventDefault(); e.stopPropagation(); addToCart(product) }

  if (loading) return <><Navbar /><div className="text-center p-5"><div className="spinner-border text-primary" /></div></>

  return (
    <>
      <Navbar />
      <section className="hero-section">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-6">
              <h1>Discover Amazing Products</h1>
              <p className="lead mb-4">Shop from multiple vendors in one place. Quality products, great prices.</p>
              <Link to="/products" className="btn btn-light btn-lg me-3">Shop Now <i className="bi bi-arrow-right ms-2"></i></Link>
              <Link to="/register" className="btn btn-outline-light btn-lg">Become a Vendor</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-5">
        <div className="container">
          <h2 className="mb-4">Shop by Category</h2>
          <div className="row g-4">
            {categories.map(category => (
              <div key={category.id} className="col-6 col-md-4 col-lg-2">
                <Link to={`/products?category=${category.id}`}><div className="category-card"><OptImage src={category.image_url} alt={category.name} style={{ height: '120px', objectFit: 'cover', borderRadius: '8px', width: '100%' }} /><h6 className="mb-0">{category.name}</h6></div></Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-5 bg-light">
        <div className="container">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h2 className="mb-0">Featured Products</h2>
            <Link to="/products" className="btn btn-outline-primary">View All <i className="bi bi-arrow-right ms-1"></i></Link>
          </div>
          <div className="row g-4">
            {featuredProducts.map(product => (
              <div key={product.id} className="col-6 col-md-4 col-lg-3">
                <Link to={`/product/${product.id}`}>
                  <div className="product-card">
                    <OptImage src={product.image_urls?.[0]} alt={product.name} style={{ height: '200px', objectFit: 'cover', width: '100%' }} />
                    <div className="card-body">
                      <h6 className="mb-1 text-dark">{product.name}</h6>
                      <p className="vendor mb-2">{product.vendor?.store_name}</p>
                      <div className="d-flex justify-content-between align-items-center">
                        <span className="price">₹{product.price.toFixed(2)}</span>
                        <button className="btn btn-sm btn-primary" onClick={(e) => handleAddToCart(e, product)}><i className="bi bi-cart-plus"></i></button>
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="bg-dark text-white py-5">
        <div className="container">
          <div className="row g-4">
            <div className="col-md-4"><h5 className="mb-3">Marketplace</h5><p className="text-muted">Your one-stop shop for quality products from trusted vendors.</p></div>
            <div className="col-md-3"><h6 className="mb-3">Quick Links</h6><ul className="list-unstyled"><li className="mb-2"><Link to="/products" className="text-muted">Products</Link></li><li className="mb-2"><Link to="/register" className="text-muted">Become a Vendor</Link></li></ul></div>
          </div>
          <hr className="my-4 border-secondary" />
          <p className="text-muted text-center mb-0">© 2024 Multi-Vendor Marketplace. All rights reserved.</p>
        </div>
      </footer>
    </>
  )
}

export default Home
