import React, { useState, useEffect } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'
import { toast } from 'react-toastify'
import Navbar from '../components/Navbar'
import OptImage from '../components/OptImage'

const ProductDetail = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const { user, userType } = useAuth()
  const { addToCart } = useCart()
  const [product, setProduct] = useState(null)
  const [reviews, setReviews] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedImage, setSelectedImage] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '' })
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => { fetchProduct() }, [id])

  const fetchProduct = async () => {
    setLoading(true)
    try {
      const { data: productData, error } = await supabase.from('products').select('*, vendor:vendor_id(*), category:category_id(*)').eq('id', id).single()
      if (error || !productData) { toast.error('Product not found'); navigate('/products'); return }
      setProduct(productData)
      const { data: reviewsData } = await supabase.from('reviews').select('*, customer:customer_id(full_name)').eq('product_id', id).order('created_at', { ascending: false })
      setReviews(reviewsData || [])
    } catch (error) { console.error('Error:', error) }
    finally { setLoading(false) }
  }

  const handleAddToCart = () => { if (!product) return; addToCart(product, quantity); setQuantity(1) }
  const handleBuyNow = () => { if (!product) return; addToCart(product, quantity); navigate('/checkout') }

  const handleSubmitReview = async (e) => {
    e.preventDefault()
    if (!user || userType !== 'customer') { toast.error('Please login as a customer to submit a review'); return }
    if (!reviewForm.comment.trim()) { toast.error('Please write a review'); return }
    setSubmitting(true)
    try {
      const { error } = await supabase.from('reviews').insert([{ product_id: id, customer_id: user.id, rating: reviewForm.rating, comment: reviewForm.comment }])
      if (error) { if (error.code === '23505') toast.error('You have already reviewed this product'); else throw error }
      else { toast.success('Review submitted successfully'); setReviewForm({ rating: 5, comment: '' }); fetchProduct() }
    } catch (error) { toast.error('Failed to submit review') }
    finally { setSubmitting(false) }
  }

  const renderStars = (rating) => [1, 2, 3, 4, 5].map(star => <i key={star} className={`bi bi-star-fill ${star <= rating ? 'text-warning' : 'text-muted'}`} />)

  const averageRating = reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1) : 0

  if (loading) return <><Navbar /><div className="text-center p-5"><div className="spinner-border text-primary" /></div></>
  if (!product) return null

  return (
    <>
      <Navbar />
      <div className="container py-4">
        <nav aria-label="breadcrumb" className="mb-4">
          <ol className="breadcrumb"><li className="breadcrumb-item"><Link to="/">Home</Link></li><li className="breadcrumb-item"><Link to="/products">Products</Link></li>{product.category && <li className="breadcrumb-item">{product.category.name}</li>}<li className="breadcrumb-item active">{product.name}</li></ol>
        </nav>
        <div className="row g-5 mb-5">
          <div className="col-md-6">
            <div className="card mb-3"><OptImage src={product.image_urls?.[selectedImage]} alt={product.name} style={{ height: '400px', objectFit: 'cover', width: '100%', borderRadius: '8px' }} /></div>
            {product.image_urls?.length > 1 && <div className="d-flex gap-2 overflow-auto">{product.image_urls.map((img, idx) => <OptImage key={idx} src={img} alt={`${product.name} ${idx + 1}`} className={`rounded ${selectedImage === idx ? 'border border-3 border-primary' : ''}`} style={{ width: '80px', height: '80px', objectFit: 'cover', cursor: 'pointer', flexShrink: 0 }} />)}</div>}
          </div>
          <div className="col-md-6">
            <span className="badge bg-light text-dark mb-2">{product.category?.name}</span>
            <h2 className="mb-2">{product.name}</h2>
            <div className="d-flex align-items-center gap-2 mb-3"><div className="rating-stars">{renderStars(Math.round(averageRating))}</div><span className="text-muted">{averageRating} ({reviews.length} review{reviews.length !== 1 ? 's' : ''})</span></div>
            <p className="text-muted mb-3">{product.description}</p>
            <p className="mb-1"><i className="bi bi-shop me-2"></i><strong>Sold by:</strong> {product.vendor?.store_name}</p>
            <p className="mb-3"><i className="bi bi-box me-2"></i><strong>Stock:</strong> <span className={product.stock_quantity > 0 ? 'text-success' : 'text-danger'}>{product.stock_quantity > 0 ? `${product.stock_quantity} available` : 'Out of stock'}</span></p>
            <h3 className="text-primary mb-4">₹{product.price.toFixed(2)}</h3>
            {product.stock_quantity > 0 && (<div className="d-flex align-items-center gap-3 mb-4"><div className="quantity-selector"><button onClick={() => setQuantity(Math.max(1, quantity - 1))}><i className="bi bi-dash"></i></button><span>{quantity}</span><button onClick={() => setQuantity(Math.min(product.stock_quantity, quantity + 1))}><i className="bi bi-plus"></i></button></div><span className="text-muted">Total: <strong className="text-dark">₹{(product.price * quantity).toFixed(2)}</strong></span></div>)}
            <div className="d-flex gap-3">
              <button className="btn btn-primary btn-lg" onClick={handleAddToCart} disabled={product.stock_quantity === 0}><i className="bi bi-cart-plus me-2"></i>Add to Cart</button>
              <button className="btn btn-outline-primary btn-lg" onClick={handleBuyNow} disabled={product.stock_quantity === 0}>Buy Now</button>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-12">
            <h4 className="mb-4">Customer Reviews</h4>
            <div className="card mb-4"><div className="card-body"><div className="row align-items-center"><div className="col-md-4 text-center mb-3 mb-md-0"><h1 className="display-4 mb-0">{averageRating}</h1><div className="rating-stars mb-2">{renderStars(Math.round(averageRating))}</div><p className="text-muted mb-0">{reviews.length} reviews</p></div></div></div></div>
            {user && userType === 'customer' && (<div className="card mb-4"><div className="card-body"><h5 className="mb-3">Write a Review</h5><form onSubmit={handleSubmitReview}><div className="mb-3"><label className="form-label">Rating</label><div className="d-flex gap-1">{[1, 2, 3, 4, 5].map(star => <i key={star} className={`bi bi-star-fill ${star <= reviewForm.rating ? 'text-warning' : 'text-muted'}`} style={{ cursor: 'pointer', fontSize: '1.5rem' }} onClick={() => setReviewForm({ ...reviewForm, rating: star })} />)}</div></div><div className="mb-3"><label className="form-label">Your Review</label><textarea className="form-control" rows="3" value={reviewForm.comment} onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })} placeholder="Share your experience..." /></div><button type="submit" className="btn btn-primary" disabled={submitting}>{submitting ? <><span className="spinner-border spinner-border-sm me-2"></span>Submitting...</> : 'Submit Review'}</button></form></div></div>)}
            {reviews.length === 0 ? <div className="text-center py-4 text-muted"><i className="bi bi-chat-square-text fs-1 d-block mb-2"></i>No reviews yet. Be the first!</div> : (<div className="list-group list-group-flush">{reviews.map(review => <div key={review.id} className="list-group-item py-3 px-0"><div className="d-flex justify-content-between align-items-start"><div><div className="d-flex align-items-center gap-2 mb-1"><strong>{review.customer?.full_name || 'Anonymous'}</strong><div className="rating-stars">{renderStars(review.rating)}</div></div><p className="mb-0">{review.comment}</p></div><small className="text-muted">{new Date(review.created_at).toLocaleDateString()}</small></div></div>)}</div>)}
          </div>
        </div>
      </div>
    </>
  )
}

export default ProductDetail
