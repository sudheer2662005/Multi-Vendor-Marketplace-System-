import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { toast } from 'react-toastify'

const Register = () => {
  const [userType, setUserType] = useState('customer')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()
  const { registerVendor, registerCustomer, loginCustomer } = useAuth()

  const [customerData, setCustomerData] = useState({ email: '', password: '', confirmPassword: '', fullName: '', phone: '', address: '', city: '', postalCode: '' })
  const [vendorData, setVendorData] = useState({ email: '', password: '', confirmPassword: '', storeName: '', ownerName: '', phone: '', address: '' })

  const handleCustomerSubmit = async (e) => {
    e.preventDefault()
    if (customerData.password !== customerData.confirmPassword) { toast.error('Passwords do not match'); return }
    setLoading(true)
    try {
      await registerCustomer({ email: customerData.email, password: customerData.password, fullName: customerData.fullName, phone: customerData.phone, address: customerData.address, city: customerData.city, postalCode: customerData.postalCode })
      await loginCustomer(customerData.email, customerData.password)
      toast.success('Registration successful!'); navigate('/customer')
    } catch (error) { toast.error(error.message || 'Registration failed') }
    finally { setLoading(false) }
  }

  const handleVendorSubmit = async (e) => {
    e.preventDefault()
    if (vendorData.password !== vendorData.confirmPassword) { toast.error('Passwords do not match'); return }
    setLoading(true)
    try {
      await registerVendor({ email: vendorData.email, password: vendorData.password, storeName: vendorData.storeName, ownerName: vendorData.ownerName, phone: vendorData.phone, address: vendorData.address })
      toast.success('Application submitted! Please wait for admin approval.'); navigate('/login')
    } catch (error) { toast.error(error.message || 'Registration failed') }
    finally { setLoading(false) }
  }

  return (
    <div className="auth-container">
      <div className="auth-card" style={{ maxWidth: userType === 'vendor' ? '500px' : '450px' }}>
        <div className="text-center mb-4">
          <Link to="/" className="text-decoration-none"><h2 className="d-flex align-items-center justify-content-center gap-2"><i className="bi bi-shop text-primary"></i>Marketplace</h2></Link>
          <p className="text-muted">Create your account</p>
        </div>
        <div className="d-flex justify-content-center mb-4">
          <div className="btn-group" role="group">
            <button type="button" className={`btn ${userType === 'customer' ? 'btn-primary' : 'btn-outline-primary'}`} onClick={() => setUserType('customer')}><i className="bi bi-person me-1"></i>Customer</button>
            <button type="button" className={`btn ${userType === 'vendor' ? 'btn-primary' : 'btn-outline-primary'}`} onClick={() => setUserType('vendor')}><i className="bi bi-shop-window me-1"></i>Vendor</button>
          </div>
        </div>

        {userType === 'customer' ? (
          <form onSubmit={handleCustomerSubmit}>
            <div className="row">
              <div className="col-12 mb-3"><label className="form-label">Full Name *</label><input type="text" className="form-control" value={customerData.fullName} onChange={(e) => setCustomerData({ ...customerData, fullName: e.target.value })} required /></div>
              <div className="col-md-6 mb-3"><label className="form-label">Email *</label><input type="email" className="form-control" value={customerData.email} onChange={(e) => setCustomerData({ ...customerData, email: e.target.value })} required /></div>
              <div className="col-md-6 mb-3"><label className="form-label">Phone</label><input type="tel" className="form-control" value={customerData.phone} onChange={(e) => setCustomerData({ ...customerData, phone: e.target.value })} /></div>
              <div className="col-md-6 mb-3"><label className="form-label">Password *</label><input type="password" className="form-control" value={customerData.password} onChange={(e) => setCustomerData({ ...customerData, password: e.target.value })} required /></div>
              <div className="col-md-6 mb-3"><label className="form-label">Confirm Password *</label><input type="password" className="form-control" value={customerData.confirmPassword} onChange={(e) => setCustomerData({ ...customerData, confirmPassword: e.target.value })} required /></div>
              <div className="col-12 mb-3"><label className="form-label">Address</label><input type="text" className="form-control" value={customerData.address} onChange={(e) => setCustomerData({ ...customerData, address: e.target.value })} /></div>
              <div className="col-md-6 mb-3"><label className="form-label">City</label><input type="text" className="form-control" value={customerData.city} onChange={(e) => setCustomerData({ ...customerData, city: e.target.value })} /></div>
              <div className="col-md-6 mb-3"><label className="form-label">Postal Code</label><input type="text" className="form-control" value={customerData.postalCode} onChange={(e) => setCustomerData({ ...customerData, postalCode: e.target.value })} /></div>
            </div>
            <button type="submit" className="btn btn-primary w-100 mt-2" disabled={loading}>{loading ? <><span className="spinner-border spinner-border-sm me-2"></span>Creating account...</> : 'Create Account'}</button>
          </form>
        ) : (
          <form onSubmit={handleVendorSubmit}>
            <div className="row">
              <div className="col-md-6 mb-3"><label className="form-label">Store Name *</label><input type="text" className="form-control" value={vendorData.storeName} onChange={(e) => setVendorData({ ...vendorData, storeName: e.target.value })} required /></div>
              <div className="col-md-6 mb-3"><label className="form-label">Owner Name *</label><input type="text" className="form-control" value={vendorData.ownerName} onChange={(e) => setVendorData({ ...vendorData, ownerName: e.target.value })} required /></div>
              <div className="col-12 mb-3"><label className="form-label">Email *</label><input type="email" className="form-control" value={vendorData.email} onChange={(e) => setVendorData({ ...vendorData, email: e.target.value })} required /></div>
              <div className="col-md-6 mb-3"><label className="form-label">Password *</label><input type="password" className="form-control" value={vendorData.password} onChange={(e) => setVendorData({ ...vendorData, password: e.target.value })} required /></div>
              <div className="col-md-6 mb-3"><label className="form-label">Confirm Password *</label><input type="password" className="form-control" value={vendorData.confirmPassword} onChange={(e) => setVendorData({ ...vendorData, confirmPassword: e.target.value })} required /></div>
              <div className="col-12 mb-3"><label className="form-label">Phone</label><input type="tel" className="form-control" value={vendorData.phone} onChange={(e) => setVendorData({ ...vendorData, phone: e.target.value })} /></div>
              <div className="col-12 mb-3"><label className="form-label">Business Address</label><textarea className="form-control" value={vendorData.address} onChange={(e) => setVendorData({ ...vendorData, address: e.target.value })} rows="2" /></div>
            </div>
            <div className="alert alert-info mb-3"><i className="bi bi-info-circle me-2"></i>Your application will be reviewed by admin.</div>
            <button type="submit" className="btn btn-primary w-100" disabled={loading}>{loading ? <><span className="spinner-border spinner-border-sm me-2"></span>Submitting...</> : 'Submit Application'}</button>
          </form>
        )}
        <div className="text-center mt-4"><p className="text-muted">Already have an account? <Link to="/login">Sign in</Link></p></div>
      </div>
    </div>
  )
}

export default Register
