import React, { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import Navbar from '../components/Navbar'
import OptImage from '../components/OptImage'

const OrderSuccess = ({ user }) => {
  const { orderId } = useParams()
  const [order, setOrder] = useState(null)
  const [orderItems, setOrderItems] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { fetchOrder() }, [orderId])

  const fetchOrder = async () => {
    try {
      const { data: orderData } = await supabase.from('orders').select('*').eq('id', orderId).single()
      const { data: items } = await supabase.from('order_items').select('*, product:product_id(name, image_urls), vendor:vendor_id(store_name)').eq('order_id', orderId)
      setOrder(orderData); setOrderItems(items || [])
    } catch (error) { console.error('Error:', error) }
    finally { setLoading(false) }
  }

  if (loading) return <><Navbar /><div className="text-center p-5"><div className="spinner-border text-primary" /></div></>

  return (
    <>
      <Navbar />
      <div className="container py-5">
        <div className="text-center mb-5">
          <div className="mb-4"><i className="bi bi-check-circle-fill text-success" style={{ fontSize: '5rem' }}></i></div>
          <h2>Order Placed Successfully!</h2>
          <p className="text-muted">Thank you for your purchase. Your order has been confirmed.</p>
          <p className="mb-0">Order ID: <strong>{orderId}</strong></p>
        </div>
        <div className="row justify-content-center">
          <div className="col-lg-8">
            <div className="card mb-4">
              <div className="card-body">
                <h5 className="mb-4">Order Details</h5>
                <div className="row mb-4">
                  <div className="col-md-6"><p className="text-muted mb-1">Shipping Address</p><p className="mb-0">{order?.shipping_address}</p></div>
                  <div className="col-md-6"><p className="text-muted mb-1">Payment Method</p><p className="mb-0 text-capitalize">{order?.payment_method}</p></div>
                </div>
                <hr />
                <h6 className="mb-3">Items</h6>
                {orderItems.map(item => <div key={item.id} className="d-flex align-items-center gap-3 py-2 border-bottom"><OptImage src={item.product?.image_urls?.[0]} alt={item.product?.name} style={{ width: 60, height: 60, objectFit: 'cover', borderRadius: 8, flexShrink: 0 }} /><div className="flex-grow-1"><h6 className="mb-0">{item.product?.name}</h6><small className="text-muted">Sold by: {item.vendor?.store_name} • Qty: {item.quantity}</small></div><div className="text-end"><strong>₹{(item.unit_price * item.quantity).toFixed(2)}</strong></div></div>)}
                <div className="d-flex justify-content-between mt-4"><strong>Total</strong><strong className="fs-5 text-primary">₹{order?.total_amount?.toFixed(2)}</strong></div>
              </div>
            </div>
            <div className="d-flex gap-3 justify-content-center">
              <Link to="/customer/orders" className="btn btn-primary"><i className="bi bi-box-seam me-2"></i>View My Orders</Link>
              <Link to="/products" className="btn btn-outline-primary"><i className="bi bi-arrow-left me-2"></i>Continue Shopping</Link>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default OrderSuccess
