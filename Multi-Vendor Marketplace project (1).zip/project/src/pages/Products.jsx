import React, { useState, useEffect } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useCart } from '../context/CartContext'
import Navbar from '../components/Navbar'
import OptImage from '../components/OptImage'

const Products = () => {
  const [searchParams, setSearchParams] = useSearchParams()
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState(searchParams.get('search') || '')
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || '')
  const [sortBy, setSortBy] = useState('newest')
  const { addToCart } = useCart()

  useEffect(() => { fetchCategories(); fetchProducts() }, [searchParams])

  const fetchCategories = async () => { const { data } = await supabase.from('categories').select('*').eq('is_active', true); setCategories(data || []) }

  const fetchProducts = async () => {
    setLoading(true)
    try {
      let query = supabase.from('products').select('*, vendor:vendor_id(store_name), category:category_id(name)').eq('is_active', true)
      const searchParam = searchParams.get('search'); const categoryParam = searchParams.get('category')
      if (searchParam) query = query.or(`name.ilike.%${searchParam}%,description.ilike.%${searchParam}%`)
      if (categoryParam) query = query.eq('category_id', categoryParam)
      const { data } = await query.order('created_at', { ascending: false })
      let filtered = data || []
      if (sortBy === 'price_low') filtered.sort((a, b) => a.price - b.price)
      else if (sortBy === 'price_high') filtered.sort((a, b) => b.price - a.price)
      setProducts(filtered)
    } catch (error) { console.error('Error:', error) }
    finally { setLoading(false) }
  }

  const handleSearch = (e) => { e.preventDefault(); const params = {}; if (search) params.search = search; if (selectedCategory) params.category = selectedCategory; setSearchParams(params) }
  const handleCategorySelect = (categoryId) => { setSelectedCategory(categoryId); const params = {}; if (search) params.search = search; if (categoryId) params.category = categoryId; setSearchParams(params) }
  const handleAddToCart = (e, product) => { e.preventDefault(); e.stopPropagation(); addToCart(product) }
  const clearFilters = () => { setSearch(''); setSelectedCategory(''); setSearchParams({}) }

  return (
    <>
      <Navbar />
      <div className="container py-4">
        <div className="row">
          <div className="col-lg-3 mb-4">
            <div className="filter-sidebar">
              <div className="d-flex justify-content-between align-items-center mb-4"><h5 className="mb-0">Filters</h5><button className="btn btn-sm btn-link" onClick={clearFilters}>Clear All</button></div>
              <form onSubmit={handleSearch}>
                <div className="mb-4"><label className="form-label fw-semibold">Search</label><div className="input-group"><input type="text" className="form-control" placeholder="Search products..." value={search} onChange={(e) => setSearch(e.target.value)} /><button className="btn btn-primary" type="submit"><i className="bi bi-search"></i></button></div></div>
              </form>
              <div className="mb-4"><h6 className="fw-semibold">Categories</h6><div className="list-group list-group-flush">
                <button className={`list-group-item list-group-item-action ${!selectedCategory ? 'active' : ''}`} onClick={() => handleCategorySelect('')}>All Categories</button>
                {categories.map(cat => <button key={cat.id} className={`list-group-item list-group-item-action ${selectedCategory === cat.id ? 'active' : ''}`} onClick={() => handleCategorySelect(cat.id)}>{cat.name}</button>)}
              </div></div>
              <div className="mb-4"><h6 className="fw-semibold">Sort By</h6><select className="form-select" value={sortBy} onChange={(e) => setSortBy(e.target.value)}><option value="newest">Newest First</option><option value="price_low">Price: Low to High</option><option value="price_high">Price: High to Low</option></select></div>
            </div>
          </div>
          <div className="col-lg-9">
            <div className="d-flex justify-content-between align-items-center mb-4"><h4 className="mb-0">{products.length} Product{products.length !== 1 ? 's' : ''} Found</h4></div>
            {loading ? <div className="text-center py-5"><div className="spinner-border text-primary" /></div> : products.length === 0 ? <div className="empty-state"><i className="bi bi-box-seam"></i><h5>No products found</h5><p className="text-muted">Try adjusting your filters</p></div> : (
              <div className="row g-4">
                {products.map(product => (
                  <div key={product.id} className="col-sm-6 col-lg-4">
                    <Link to={`/product/${product.id}`}>
                      <div className="product-card">
                        <OptImage src={product.image_urls?.[0]} alt={product.name} style={{ height: '200px', objectFit: 'cover', width: '100%' }} />
                        <div className="card-body">
                          <span className="badge bg-light text-dark mb-2">{product.category?.name}</span>
                          <h6 className="mb-1 text-dark">{product.name}</h6>
                          <p className="vendor mb-2"><i className="bi bi-shop me-1"></i>{product.vendor?.store_name}</p>
                          <div className="d-flex justify-content-between align-items-center">
                            <span className="price">₹{product.price.toFixed(2)}</span>
                            <button className="btn btn-sm btn-primary" onClick={(e) => handleAddToCart(e, product)}><i className="bi bi-cart-plus me-1"></i>Add</button>
                          </div>
                        </div>
                      </div>
                    </Link>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  )
}

export default Products
