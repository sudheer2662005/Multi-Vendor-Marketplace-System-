import React, { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import AdminLayout from '../../components/AdminLayout'
import OptImage from '../../components/OptImage'

const AllProducts = () => {
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('')

  useEffect(() => { fetchProducts(); fetchCategories() }, [])

  const fetchCategories = async () => { const { data } = await supabase.from('categories').select('*'); setCategories(data || []) }
  const fetchProducts = async () => { setLoading(true); const { data } = await supabase.from('products').select('*, vendor:vendor_id(store_name), category:category_id(name)').order('created_at', { ascending: false }); setProducts(data || []); setLoading(false) }

  const filtered = products.filter(p => {
    const matchSearch = p.name?.toLowerCase().includes(search.toLowerCase()) || p.vendor?.store_name?.toLowerCase().includes(search.toLowerCase())
    const matchCat = !categoryFilter || p.category_id === categoryFilter
    return matchSearch && matchCat
  })

  return (
    <AdminLayout>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>All Products</h2>
        <div className="d-flex gap-2">
          <input type="text" className="form-control" placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} style={{ width: '200px' }} />
          <select className="form-select" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} style={{ width: 'auto' }}><option value="">All Categories</option>{categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        </div>
      </div>
      {loading ? <div className="text-center p-5"><div className="spinner-border text-primary" /></div> : (
        <div className="table-container">
          <table className="table table-hover">
            <thead><tr><th>Product</th><th>Category</th><th>Vendor</th><th>Price</th><th>Stock</th><th>Status</th></tr></thead>
            <tbody>
              {filtered.map(p => (
                <tr key={p.id}>
                  <td><div className="d-flex align-items-center gap-3"><OptImage src={p.image_urls?.[0]} alt={p.name} style={{ width: 50, height: 50, objectFit: 'cover', borderRadius: 8, flexShrink: 0 }} /><div><strong>{p.name}</strong><p className="text-muted small mb-0">{p.description?.substring(0, 50)}...</p></div></div></td>
                  <td>{p.category?.name || '-'}</td><td>{p.vendor?.store_name || '-'}</td>
                  <td><strong>₹{p.price?.toFixed(2)}</strong></td>
                  <td><span className={`badge ${p.stock_quantity > 0 ? 'bg-success' : 'bg-danger'}`}>{p.stock_quantity}</span></td>
                  <td><span className={`badge ${p.is_active ? 'bg-success' : 'bg-secondary'}`}>{p.is_active ? 'Active' : 'Inactive'}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AdminLayout>
  )
}

export default AllProducts
