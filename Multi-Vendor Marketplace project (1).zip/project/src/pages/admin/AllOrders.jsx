import React, { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import AdminLayout from '../../components/AdminLayout'
import OptImage from '../../components/OptImage'

const AllOrders = () => {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('')
  const [selectedOrder, setSelectedOrder] = useState(null)

  useEffect(() => { fetchOrders() }, [statusFilter])

  const fetchOrders = async () => {
    setLoading(true)
    try {
      let query = supabase.from('orders').select('*, customer:customer_id(full_name, email)').order('created_at', { ascending: false })
      if (statusFilter) query = query.eq('status', statusFilter)
      const { data } = await query
      setOrders(data || [])
    } finally { setLoading(false) }
  }

  const viewDetails = async (order) => {
    const { data: items } = await supabase.from('order_items').select('*, product:product_id(name, image_urls), vendor:vendor_id(store_name)').eq('order_id', order.id)
    setSelectedOrder({ ...order, items: items || [] })
  }

  const getBadge = (s) => `badge-${s}`

  return (
    <AdminLayout>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>All Orders</h2>
        <select className="form-select" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} style={{ width: 'auto' }}>
          <option value="">All Status</option><option value="pending">Pending</option><option value="processing">Processing</option><option value="shipped">Shipped</option><option value="delivered">Delivered</option>
        </select>
      </div>
      {loading ? <div className="text-center p-5"><div className="spinner-border text-primary" /></div> : (
        <div className="table-container">
          <table className="table table-hover">
            <thead><tr><th>Order ID</th><th>Customer</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
            <tbody>
              {orders.map(o => (
                <tr key={o.id}>
                  <td><code>{o.id.substring(0, 8)}...</code></td>
                  <td><div><strong>{o.customer?.full_name}</strong><br /><small className="text-muted">{o.customer?.email}</small></div></td>
                  <td><strong>₹{o.total_amount?.toFixed(2)}</strong></td>
                  <td>{o.payment_method?.toUpperCase()}</td>
                  <td><span className={`badge-status ${getBadge(o.status)}`}>{o.status}</span></td>
                  <td>{new Date(o.created_at).toLocaleDateString()}</td>
                  <td><button className="btn btn-sm btn-outline-primary" onClick={() => viewDetails(o)}><i className="bi bi-eye me-1"></i>View</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {selectedOrder && (
        <div className="modal d-block show" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} onClick={() => setSelectedOrder(null)}>
          <div className="modal-dialog modal-lg modal-dialog-centered" onClick={e => e.stopPropagation()}>
            <div className="modal-content">
              <div className="modal-header"><h5 className="modal-title">Order Details</h5><button type="button" className="btn-close" onClick={() => setSelectedOrder(null)}></button></div>
              <div className="modal-body">
                <div className="row mb-4"><div className="col-md-6"><h6>Customer</h6><p className="mb-1"><strong>{selectedOrder.customer?.full_name}</strong></p><p className="text-muted mb-0">{selectedOrder.customer?.email}</p></div><div className="col-md-6"><h6>Shipping Address</h6><p className="mb-0">{selectedOrder.shipping_address}</p></div></div>
                <h6>Order Items</h6>
                <table className="table"><thead><tr><th>Product</th><th>Vendor</th><th>Qty</th><th>Price</th><th>Status</th></tr></thead>
                  <tbody>{selectedOrder.items?.map(i => <tr key={i.id}><td><div className="d-flex align-items-center gap-2"><OptImage src={i.product?.image_urls?.[0]} alt={i.product?.name} style={{ width: 40, height: 40, objectFit: 'cover', borderRadius: 4, flexShrink: 0 }} /><span>{i.product?.name}</span></div></td><td>{i.vendor?.store_name}</td><td>{i.quantity}</td><td>₹{i.unit_price?.toFixed(2)}</td><td><span className={`badge-status ${getBadge(i.status)}`}>{i.status}</span></td></tr>)}</tbody>
                </table>
                <div className="d-flex justify-content-between mt-4"><div><p className="mb-1">Payment: <strong>{selectedOrder.payment_method}</strong></p><p className="mb-0">Status: <span className={`badge-status ${getBadge(selectedOrder.status)}`}>{selectedOrder.status}</span></p></div><div className="text-end"><p className="mb-1">Total Amount: <strong className="fs-5">₹{selectedOrder.total_amount?.toFixed(2)}</strong></p><p className="mb-0 text-muted">Commission: ₹{selectedOrder.total_commission?.toFixed(2)}</p></div></div>
              </div>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  )
}

export default AllOrders
