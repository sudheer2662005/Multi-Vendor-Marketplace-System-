import React, { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import AdminLayout from '../../components/AdminLayout'

const ManageCustomers = () => {
  const [customers, setCustomers] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')

  useEffect(() => { fetchCustomers() }, [])

  const fetchCustomers = async () => {
    setLoading(true)
    try {
      const { data } = await supabase.from('customers').select('*').order('created_at', { ascending: false })
      setCustomers(data || [])
    } finally { setLoading(false) }
  }

  const filtered = customers.filter(c => c.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) || c.email?.toLowerCase().includes(searchTerm.toLowerCase()))

  return (
    <AdminLayout>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Manage Customers</h2>
        <input type="text" className="form-control" placeholder="Search..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} style={{ width: '300px' }} />
      </div>
      {loading ? <div className="text-center p-5"><div className="spinner-border text-primary" /></div> : (
        <div className="table-container">
          <div className="table-responsive">
            <table className="table table-hover">
              <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>City</th><th>Registered</th></tr></thead>
              <tbody>
                {filtered.map(c => (
                  <tr key={c.id}>
                    <td><div className="d-flex align-items-center gap-2"><div className="bg-primary bg-opacity-10 rounded-circle p-2"><i className="bi bi-person"></i></div><strong>{c.full_name}</strong></div></td>
                    <td>{c.email}</td><td>{c.phone || '-'}</td><td>{c.city || '-'}</td>
                    <td>{new Date(c.created_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </AdminLayout>
  )
}

export default ManageCustomers
