import React, { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { toast } from 'react-toastify'
import AdminLayout from '../../components/AdminLayout'
import OptImage from '../../components/OptImage'

const ManageCategories = () => {
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState(null)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ name: '', description: '', image_url: '' })

  useEffect(() => { fetchCategories() }, [])

  const fetchCategories = async () => {
    setLoading(true)
    try { const { data } = await supabase.from('categories').select('*').order('created_at', { ascending: false }); setCategories(data || []) }
    finally { setLoading(false) }
  }

  const handleSubmit = async (e) => {
    e.preventDefault(); setSaving(true)
    try {
      if (editing) {
        await supabase.from('categories').update({ name: form.name, description: form.description, image_url: form.image_url, updated_at: new Date().toISOString() }).eq('id', editing.id)
        toast.success('Updated')
      } else {
        await supabase.from('categories').insert([{ name: form.name, description: form.description, image_url: form.image_url }])
        toast.success('Created')
      }
      setShowModal(false); setEditing(null); setForm({ name: '', description: '', image_url: '' }); fetchCategories()
    } catch (error) { toast.error('Failed') }
    finally { setSaving(false) }
  }

  const handleEdit = (cat) => { setEditing(cat); setForm({ name: cat.name, description: cat.description || '', image_url: cat.image_url || '' }); setShowModal(true) }
  const handleDelete = async (id) => { if (!confirm('Delete?')) return; try { await supabase.from('categories').delete().eq('id', id); toast.success('Deleted'); fetchCategories() } catch { toast.error('Failed') } }
  const openAdd = () => { setEditing(null); setForm({ name: '', description: '', image_url: '' }); setShowModal(true) }

  return (
    <AdminLayout>
      <div className="d-flex justify-content-between align-items-center mb-4"><h2>Manage Categories</h2><button className="btn btn-primary" onClick={openAdd}><i className="bi bi-plus-lg me-2"></i>Add Category</button></div>
      {loading ? <div className="text-center p-5"><div className="spinner-border text-primary" /></div> : (
        <div className="row g-4">
          {categories.map(cat => (
            <div key={cat.id} className="col-md-4 col-lg-3">
              <div className="card h-100">
                <div style={{ height: '150px', overflow: 'hidden' }}><OptImage src={cat.image_url} alt={cat.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /></div>
                <div className="card-body"><h5 className="card-title">{cat.name}</h5><p className="card-text text-muted small">{cat.description || 'No description'}</p></div>
                <div className="card-footer bg-white border-top-0 pb-3"><div className="d-flex gap-2"><button className="btn btn-sm btn-outline-primary flex-grow-1" onClick={() => handleEdit(cat)}><i className="bi bi-pencil me-1"></i>Edit</button><button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(cat.id)}><i className="bi bi-trash"></i></button></div></div>
              </div>
            </div>
          ))}
        </div>
      )}
      {showModal && (
        <div className="modal d-block show" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header"><h5 className="modal-title">{editing ? 'Edit' : 'Add'} Category</h5><button type="button" className="btn-close" onClick={() => setShowModal(false)}></button></div>
              <form onSubmit={handleSubmit}>
                <div className="modal-body">
                  <div className="mb-3"><label className="form-label">Name</label><input type="text" className="form-control" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
                  <div className="mb-3"><label className="form-label">Description</label><textarea className="form-control" rows="3" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
                  <div className="mb-3"><label className="form-label">Image URL</label><input type="url" className="form-control" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} /></div>
                </div>
                <div className="modal-footer"><button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button><button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save'}</button></div>
              </form>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  )
}

export default ManageCategories
