import React, { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { toast } from 'react-toastify'
import AdminLayout from '../../components/AdminLayout'

const ManageVendors = () => {
  const [vendors, setVendors] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')

  useEffect(() => { fetchVendors() }, [filter])

  const fetchVendors = async () => {
    setLoading(true)
    try {
      let query = supabase.from('vendors').select('*').order('created_at', { ascending: false })
      if (filter !== 'all') query = query.eq('status', filter)
      const { data } = await query
      setVendors(data || [])
    } catch (error) { console.error('Error:', error) }
    finally { setLoading(false) }
  }

  const handleApprove = async (id) => {
    try {
      await supabase.from('vendors').update({ status: 'approved', updated_at: new Date().toISOString() }).eq('id', id)
      toast.success('Vendor approved'); fetchVendors()
    } catch (error) { toast.error('Failed') }
  }

  const handleReject = async (id) => {
    if (!confirm('Reject this vendor?')) return
    try {
      await supabase.from('vendors').update({ status: 'rejected', updated_at: new Date().toISOString() }).eq('id', id)
      toast.success('Vendor rejected'); fetchVendors()
    } catch (error) { toast.error('Failed') }
  }

  const updateCommission = async (id, rate) => {
    try {
      await supabase.from('vendors').update({ commission_rate: parseFloat(rate), updated_at: new Date().toISOString() }).eq('id', id)
      toast.success('Commission updated'); fetchVendors()
    } catch (error) { toast.error('Failed') }
  }

  const getBadge = (s) => s === 'approved' ? 'badge-approved' : s === 'pending' ? 'badge-pending' : 'badge-rejected'

  return (
    <AdminLayout>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Manage Vendors</h2>
        <select className="form-select" value={filter} onChange={(e) => setFilter(e.target.value)} style={{ width: 'auto' }}>
          <option value="all">All Vendors</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option>
        </select>
      </div>
      {loading ? <div className="text-center p-5"><div className="spinner-border text-primary" /></div> : (
        <div className="table-container">
          <div className="table-responsive">
            <table className="table table-hover">
              <thead><tr><th>Store Name</th><th>Owner</th><th>Email</th><th>Commission</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                {vendors.map(v => (
                  <tr key={v.id}>
                    <td><strong>{v.store_name}</strong></td>
                    <td>{v.owner_name}</td>
                    <td>{v.email}</td>
                    <td><div className="d-flex align-items-center gap-2"><input type="number" className="form-control form-control-sm" style={{ width: '70px' }} value={v.commission_rate} onChange={(e) => updateCommission(v.id, e.target.value)} min="0" max="100" step="0.5" /><span>%</span></div></td>
                    <td><span className={`badge-status ${getBadge(v.status)}`}>{v.status}</span></td>
                    <td>{v.status === 'pending' && (<div className="d-flex gap-2"><button className="btn btn-sm btn-success" onClick={() => handleApprove(v.id)}><i className="bi bi-check-lg"></i></button><button className="btn btn-sm btn-danger" onClick={() => handleReject(v.id)}><i className="bi bi-x-lg"></i></button></div>)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </AdminLayout>
  )
}

export default ManageVendors
