import React, { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { toast } from 'react-toastify'
import AdminLayout from '../../components/AdminLayout'

const Settlements = () => {
  const [vendors, setVendors] = useState([])
  const [settlements, setSettlements] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { fetchData() }, [])

  const fetchData = async () => {
    setLoading(true)
    try {
      const { data: v } = await supabase.from('vendors').select('*').eq('status', 'approved').order('store_name')
      const { data: s } = await supabase.from('vendor_settlements').select('*, vendor:vendor_id(store_name)').order('created_at', { ascending: false }).limit(20)
      setVendors(v || []); setSettlements(s || [])
    } finally { setLoading(false) }
  }

  const handleSettle = async (vendor) => {
    const { data: items } = await supabase.from('order_items').select('vendor_earning').eq('vendor_id', vendor.id).eq('status', 'delivered')
    const pendingAmount = items?.reduce((sum, i) => sum + parseFloat(i.vendor_earning || 0), 0) || 0
    if (pendingAmount <= 0) { toast.info('No pending earnings'); return }
    if (!confirm(`Settle ₹${pendingAmount.toFixed(2)} to ${vendor.store_name}?`)) return
    try {
      await supabase.from('vendor_settlements').insert([{ vendor_id: vendor.id, amount: pendingAmount, status: 'processed', settled_at: new Date().toISOString() }])
      toast.success(`Settlement of ₹${pendingAmount.toFixed(2)} processed`); fetchData()
    } catch { toast.error('Failed') }
  }

  return (
    <AdminLayout>
      <h2 className="mb-4">Vendor Settlements</h2>
      {loading ? <div className="text-center p-5"><div className="spinner-border text-primary" /></div> : (
        <>
          <div className="row g-4 mb-4">
            {vendors.map(v => (
              <div key={v.id} className="col-md-4">
                <div className="dashboard-card">
                  <div className="d-flex align-items-center gap-3 mb-3"><div className="bg-primary bg-opacity-10 rounded-circle p-3"><i className="bi bi-shop text-primary fs-4"></i></div><div><h5 className="mb-0">{v.store_name}</h5><small className="text-muted">{v.owner_name}</small></div></div>
                  <div className="d-flex justify-content-between align-items-center mb-3"><div><small className="text-muted">Total Earned</small><p className="mb-0 fs-5 fw-bold">₹{(v.total_earnings || 0).toFixed(2)}</p></div><div className="text-end"><small className="text-muted">Commission</small><p className="mb-0 fw-bold">{v.commission_rate}%</p></div></div>
                  <button className="btn btn-primary w-100" onClick={() => handleSettle(v)}><i className="bi bi-bank me-2"></i>Process Settlement</button>
                </div>
              </div>
            ))}
          </div>
          <div className="dashboard-card">
            <h5 className="mb-4">Recent Settlements</h5>
            {settlements.length === 0 ? <p className="text-muted text-center py-4 mb-0">No settlements yet</p> : (
              <table className="table"><thead><tr><th>Date</th><th>Vendor</th><th>Amount</th><th>Status</th></tr></thead><tbody>{settlements.map(s => <tr key={s.id}><td>{new Date(s.created_at).toLocaleDateString()}</td><td>{s.vendor?.store_name}</td><td><strong>₹{s.amount?.toFixed(2)}</strong></td><td><span className={`badge-status ${s.status === 'processed' ? 'badge-approved' : 'badge-pending'}`}>{s.status}</span></td></tr>)}</tbody></table>
            )}
          </div>
        </>
      )}
    </AdminLayout>
  )
}

export default Settlements
