import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import AdminLayout from '../../components/AdminLayout'

const AdminDashboard = () => {
  const { user } = useAuth()
  const [stats, setStats] = useState({ totalVendors: 0, pendingVendors: 0, totalCustomers: 0, totalCategories: 0, totalProducts: 0, totalOrders: 0, totalRevenue: 0, totalCommission: 0 })
  const [recentOrders, setRecentOrders] = useState([])
  const [pendingVendors, setPendingVendors] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { fetchDashboardData() }, [])

  const fetchDashboardData = async () => {
    try {
      const [v1, v2, v3, v4, v5, o1] = await Promise.all([
        supabase.from('vendors').select('id', { count: 'exact', head: true }).eq('status', 'approved'),
        supabase.from('vendors').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('customers').select('id', { count: 'exact', head: true }),
        supabase.from('categories').select('id', { count: 'exact', head: true }),
        supabase.from('products').select('id', { count: 'exact', head: true }).eq('is_active', true),
        supabase.from('orders').select('total_amount, total_commission')
      ])
      const totalRevenue = o1.data?.reduce((sum, o) => sum + parseFloat(o.total_amount || 0), 0) || 0
      const totalCommission = o1.data?.reduce((sum, o) => sum + parseFloat(o.total_commission || 0), 0) || 0
      setStats({ totalVendors: v1.count || 0, pendingVendors: v2.count || 0, totalCustomers: v3.count || 0, totalCategories: v4.count || 0, totalProducts: v5.count || 0, totalOrders: o1.data?.length || 0, totalRevenue, totalCommission })
      const { data: orders } = await supabase.from('orders').select('*, customer:customer_id(full_name, email)').order('created_at', { ascending: false }).limit(5)
      setRecentOrders(orders || [])
      const { data: vendors } = await supabase.from('vendors').select('*').eq('status', 'pending').order('created_at', { ascending: false }).limit(5)
      setPendingVendors(vendors || [])
    } catch (error) { console.error('Error:', error) }
    finally { setLoading(false) }
  }

  if (loading) return <AdminLayout><div className="text-center p-5"><div className="spinner-border text-primary" /></div></AdminLayout>

  return (
    <AdminLayout>
      <div className="d-flex justify-content-between align-items-center mb-4"><div><h2 className="mb-1">Dashboard</h2><p className="text-muted mb-0">Welcome back, {user?.full_name}</p></div></div>
      <div className="row g-4 mb-4">
        <div className="col-md-6 col-xl-3"><div className="stat-card"><div className="d-flex justify-content-between align-items-center"><div><p className="mb-1 opacity-75">Total Revenue</p><h3 className="mb-0">₹{stats.totalRevenue.toFixed(2)}</h3></div><i className="bi bi-currency-rupee fs-1 opacity-50"></i></div></div></div>
        <div className="col-md-6 col-xl-3"><div className="stat-card success"><div className="d-flex justify-content-between align-items-center"><div><p className="mb-1 opacity-75">Total Orders</p><h3 className="mb-0">{stats.totalOrders}</h3></div><i className="bi bi-bag-check fs-1 opacity-50"></i></div></div></div>
        <div className="col-md-6 col-xl-3"><div className="stat-card warning"><div className="d-flex justify-content-between align-items-center"><div><p className="mb-1 opacity-75">Commission Earned</p><h3 className="mb-0">₹{stats.totalCommission.toFixed(2)}</h3></div><i className="bi bi-graph-up-arrow fs-1 opacity-50"></i></div></div></div>
        <div className="col-md-6 col-xl-3"><div className="stat-card danger"><div className="d-flex justify-content-between align-items-center"><div><p className="mb-1 opacity-75">Pending Approvals</p><h3 className="mb-0">{stats.pendingVendors}</h3></div><i className="bi bi-hourglass-split fs-1 opacity-50"></i></div></div></div>
      </div>
      <div className="row g-4 mb-4">
        <div className="col-sm-6 col-xl-3"><Link to="/admin/vendors"><div className="dashboard-card"><div className="d-flex align-items-center"><div className="bg-primary bg-opacity-10 rounded-circle p-3 me-3"><i className="bi bi-shop fs-4 text-primary"></i></div><div><h4 className="mb-0">{stats.totalVendors}</h4><p className="text-muted mb-0">Active Vendors</p></div></div></div></Link></div>
        <div className="col-sm-6 col-xl-3"><Link to="/admin/customers"><div className="dashboard-card"><div className="d-flex align-items-center"><div className="bg-success bg-opacity-10 rounded-circle p-3 me-3"><i className="bi bi-people fs-4 text-success"></i></div><div><h4 className="mb-0">{stats.totalCustomers}</h4><p className="text-muted mb-0">Customers</p></div></div></div></Link></div>
        <div className="col-sm-6 col-xl-3"><Link to="/admin/products"><div className="dashboard-card"><div className="d-flex align-items-center"><div className="bg-warning bg-opacity-10 rounded-circle p-3 me-3"><i className="bi bi-box-seam fs-4 text-warning"></i></div><div><h4 className="mb-0">{stats.totalProducts}</h4><p className="text-muted mb-0">Products</p></div></div></div></Link></div>
        <div className="col-sm-6 col-xl-3"><Link to="/admin/categories"><div className="dashboard-card"><div className="d-flex align-items-center"><div className="bg-info bg-opacity-10 rounded-circle p-3 me-3"><i className="bi bi-tags fs-4 text-info"></i></div><div><h4 className="mb-0">{stats.totalCategories}</h4><p className="text-muted mb-0">Categories</p></div></div></div></Link></div>
      </div>
      <div className="row g-4">
        <div className="col-lg-6"><div className="dashboard-card"><div className="d-flex justify-content-between align-items-center mb-3"><h5 className="mb-0">Pending Vendor Approvals</h5>{stats.pendingVendors > 0 && <Link to="/admin/vendors" className="btn btn-sm btn-outline-primary">View All</Link>}</div>{pendingVendors.length === 0 ? <p className="text-muted text-center py-4 mb-0">No pending approvals</p> : <div className="list-group list-group-flush">{pendingVendors.map(v => <div key={v.id} className="list-group-item d-flex justify-content-between align-items-center"><div><h6 className="mb-0">{v.store_name}</h6><small className="text-muted">{v.email}</small></div><span className="badge bg-warning">Pending</span></div>)}</div>}</div></div>
        <div className="col-lg-6"><div className="dashboard-card"><div className="d-flex justify-content-between align-items-center mb-3"><h5 className="mb-0">Recent Orders</h5><Link to="/admin/orders" className="btn btn-sm btn-outline-primary">View All</Link></div>{recentOrders.length === 0 ? <p className="text-muted text-center py-4 mb-0">No orders yet</p> : <div className="list-group list-group-flush">{recentOrders.map(o => <div key={o.id} className="list-group-item"><div className="d-flex justify-content-between align-items-center mb-1"><h6 className="mb-0">{o.customer?.full_name || 'Customer'}</h6><strong>₹{o.total_amount?.toFixed(2)}</strong></div><div className="d-flex justify-content-between align-items-center"><small className="text-muted">{new Date(o.created_at).toLocaleDateString()}</small><span className={`badge-status badge-${o.status}`}>{o.status}</span></div></div>)}</div>}</div></div>
      </div>
    </AdminLayout>
  )
}

export default AdminDashboard
