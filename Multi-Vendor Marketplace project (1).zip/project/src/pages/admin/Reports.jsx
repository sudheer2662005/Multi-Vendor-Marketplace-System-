import React, { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import AdminLayout from '../../components/AdminLayout'

const Reports = () => {
  const [loading, setLoading] = useState(true)
  const [dateRange, setDateRange] = useState('month')
  const [reportData, setReportData] = useState({ totalRevenue: 0, totalOrders: 0, totalCommission: 0, topVendors: [] })

  useEffect(() => { fetchReportData() }, [dateRange])

  const fetchReportData = async () => {
    setLoading(true)
    try {
      const now = new Date(); let startDate
      switch (dateRange) {
        case 'week': startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000); break
        case 'month': startDate = new Date(now.getFullYear(), now.getMonth(), 1); break
        case 'year': startDate = new Date(now.getFullYear(), 0, 1); break
        default: startDate = new Date(0)
      }
      const { data: orders } = await supabase.from('orders').select('*').gte('created_at', startDate.toISOString())
      const totalRevenue = orders?.reduce((sum, o) => sum + parseFloat(o.total_amount || 0), 0) || 0
      const totalCommission = orders?.reduce((sum, o) => sum + parseFloat(o.total_commission || 0), 0) || 0

      const orderIds = orders?.map(o => o.id) || []
      let vendorStats = []
      if (orderIds.length > 0) {
        const { data: orderItems } = await supabase.from('order_items').select('*, vendor:vendor_id(store_name)').in('order_id', orderIds)
        const vendorMap = {}
        orderItems?.forEach(item => {
          if (!vendorMap[item.vendor_id]) vendorMap[item.vendor_id] = { vendor_id: item.vendor_id, vendor_name: item.vendor?.store_name, total_earning: 0, total_sales: 0 }
          vendorMap[item.vendor_id].total_earning += parseFloat(item.vendor_earning || 0)
          vendorMap[item.vendor_id].total_sales += item.quantity
        })
        vendorStats = Object.values(vendorMap).sort((a, b) => b.total_earning - a.total_earning).slice(0, 5)
      }
      setReportData({ totalRevenue, totalOrders: orders?.length || 0, totalCommission, topVendors: vendorStats })
    } catch (error) { console.error('Error:', error) }
    finally { setLoading(false) }
  }

  return (
    <AdminLayout>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Reports & Analytics</h2>
        <select className="form-select" value={dateRange} onChange={(e) => setDateRange(e.target.value)} style={{ width: 'auto' }}>
          <option value="all">All Time</option><option value="week">This Week</option><option value="month">This Month</option><option value="year">This Year</option>
        </select>
      </div>
      {loading ? <div className="text-center p-5"><div className="spinner-border text-primary" /></div> : (
        <>
          <div className="row g-4 mb-4">
            <div className="col-md-4"><div className="stat-card"><div className="d-flex justify-content-between align-items-center"><div><p className="mb-1 opacity-75">Total Revenue</p><h3 className="mb-0">₹{reportData.totalRevenue.toFixed(2)}</h3></div><i className="bi bi-currency-rupee fs-1 opacity-50"></i></div></div></div>
            <div className="col-md-4"><div className="stat-card success"><div className="d-flex justify-content-between align-items-center"><div><p className="mb-1 opacity-75">Total Orders</p><h3 className="mb-0">{reportData.totalOrders}</h3></div><i className="bi bi-bag-check fs-1 opacity-50"></i></div></div></div>
            <div className="col-md-4"><div className="stat-card warning"><div className="d-flex justify-content-between align-items-center"><div><p className="mb-1 opacity-75">Commission Earned</p><h3 className="mb-0">₹{reportData.totalCommission.toFixed(2)}</h3></div><i className="bi bi-graph-up-arrow fs-1 opacity-50"></i></div></div></div>
          </div>
          <div className="row g-4">
            <div className="col-lg-6">
              <div className="dashboard-card"><h5 className="mb-4">Top Vendors by Earnings</h5>{reportData.topVendors.length === 0 ? <p className="text-muted text-center py-4 mb-0">No data</p> : <div className="list-group list-group-flush">{reportData.topVendors.map((v, i) => <div key={v.vendor_id} className="list-group-item d-flex justify-content-between align-items-center px-0"><div className="d-flex align-items-center gap-3"><span className="badge rounded-circle bg-primary bg-opacity-75" style={{ width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{i + 1}</span><div><h6 className="mb-0">{v.vendor_name}</h6><small className="text-muted">{v.total_sales} items sold</small></div></div><strong className="text-success">₹{v.total_earning.toFixed(2)}</strong></div>)}</div>}</div>
            </div>
            <div className="col-lg-6">
              <div className="dashboard-card"><h5 className="mb-4">Revenue Summary</h5><div className="p-4"><div className="d-flex justify-content-between mb-3"><span>Total Order Value</span><strong>₹{reportData.totalRevenue.toFixed(2)}</strong></div><div className="d-flex justify-content-between mb-3"><span>Commission Earned</span><strong className="text-success">₹{reportData.totalCommission.toFixed(2)}</strong></div><hr /><div className="d-flex justify-content-between"><span>Vendor Payouts</span><strong>₹{(reportData.totalRevenue - reportData.totalCommission).toFixed(2)}</strong></div></div></div>
            </div>
          </div>
        </>
      )}
    </AdminLayout>
  )
}

export default Reports
