import React, { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import CustomerLayout from '../../components/CustomerLayout'
import OptImage from '../../components/OptImage'

const CustomerOrders = () => {
  const { user } = useAuth()
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedOrder, setSelectedOrder] = useState(null)

  useEffect(() => { fetchOrders() }, [])

  const fetchOrders = async () => {
    setLoading(true)
    try {
      const { data } = await supabase.from('orders').select('*').eq('customer_id', user.id).order('created_at', { ascending: false })
      setOrders(data || [])
    } finally { setLoading(false) }
  }

  const viewDetails = async (order) => {
    const { data: items } = await supabase.from('order_items').select('*, product:product_id(name, image_urls), vendor:vendor_id(store_name)').eq('order_id', order.id)
    setSelectedOrder({ ...order, items: items || [] })
  }

  const getBadge = (s) => `badge-${s}`

  return (
    <CustomerLayout>
      <h2 className="mb-4">My Orders</h2>
      {loading ? <div className="text-center p-5"><div className="spinner-border text-primary" /></div> : orders.length === 0 ? <div className="dashboard-card text-center py-5"><i className="bi bi-box-seam fs-1 d-block mb-3 text-muted"></i><p className="text-muted mb-3">No orders yet</p></div> : (
        <div className="row g-4">
          {orders.map(o => (
            <div key={o.id} className="col-md-6 col-lg-4">
              <div className="dashboard-card">
                <div className="d-flex justify-content-between align-items-start mb-3"><div><small className="text-muted">Order #{o.id.substring(0, 8)}</small><h5 className="mb-0">₹{o.total_amount?.toFixed(2)}</h5></div><span className={`badge-status ${getBadge(o.status)}`}>{o.status}</span></div>
                <p className="text-muted small mb-3">{new Date(o.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                <div className="mb-3"><small className="text-muted">Payment: </small><strong>{o.payment_method?.toUpperCase()}</strong></div>
                <button className="btn btn-outline-primary w-100" onClick={() => viewDetails(o)}><i className="bi bi-eye me-2"></i>View Details</button>
              </div>
            </div>
          ))}
        </div>
      )}
      {selectedOrder && (
        <div className="modal d-block show" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} onClick={() => setSelectedOrder(null)}>
          <div className="modal-dialog modal-lg modal-dialog-centered" onClick={e => e.stopPropagation()}>
            <div className="modal-content">
              <div className="modal-header"><h5 className="modal-title">Order Details</h5><button type="button" className="btn-close" onClick={() => setSelectedOrder(null)}></button></div>
              <div className="modal-body">
                <div className="mb-4"><h6>Order Status</h6><div className="d-flex justify-content-between mt-3">{['pending', 'processing', 'shipped', 'delivered'].map((step, idx) => {
                  const statusOrder = ['pending', 'processing', 'shipped', 'delivered']; const current = statusOrder.indexOf(selectedOrder.status); const stepIdx = statusOrder.indexOf(step); const completed = stepIdx <= current
                  return <div key={step} className="text-center flex-grow-1"><div className="rounded-circle mx-auto mb-2 d-flex align-items-center justify-content-center" style={{ width: 40, height: 40, backgroundColor: completed ? '#10b981' : '#e2e8f0', color: completed ? 'white' : '#94a3b8' }}>{completed ? <i className="bi bi-check"></i> : idx + 1}</div><small className={completed ? '' : 'text-muted'}>{step.charAt(0).toUpperCase() + step.slice(1)}</small></div>
                })}</div></div>
                <hr /><h6>Order Items</h6>
                <div className="list-group list-group-flush mb-4">{selectedOrder.items?.map(i => <div key={i.id} className="list-group-item d-flex align-items-center gap-3 px-0"><OptImage src={i.product?.image_urls?.[0]} alt={i.product?.name} style={{ width: 60, height: 60, objectFit: 'cover', borderRadius: 8, flexShrink: 0 }} /><div className="flex-grow-1"><h6 className="mb-0">{i.product?.name}</h6><small className="text-muted">Sold by: {i.vendor?.store_name}</small></div><div className="text-end"><p className="mb-0">Qty: {i.quantity}</p><strong>₹{(i.unit_price * i.quantity).toFixed(2)}</strong></div></div>)}</div>
                <div className="bg-light rounded p-3 mb-3"><h6 className="mb-2"><i className="bi bi-geo-alt me-2"></i>Shipping Address</h6><p className="mb-0">{selectedOrder.shipping_address}</p></div>
                <div className="d-flex justify-content-between"><div><p className="mb-1">Payment: <strong>{selectedOrder.payment_method}</strong></p><p className="mb-0">Date: {new Date(selectedOrder.created_at).toLocaleDateString()}</p></div><div className="text-end"><h4 className="mb-0">₹{selectedOrder.total_amount?.toFixed(2)}</h4><small className="text-muted">Total</small></div></div>
              </div>
            </div>
          </div>
        </div>
      )}
    </CustomerLayout>
  )
}

export default CustomerOrders
