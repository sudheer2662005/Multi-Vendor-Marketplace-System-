import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import CustomerLayout from '../../components/CustomerLayout'

const CustomerDashboard = () => {
  const { user } = useAuth()
  const [stats, setStats] = useState({ totalOrders: 0, pendingOrders: 0, totalSpent: 0 })
  const [recentOrders, setRecentOrders] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { fetchDashboardData() }, [])

  const fetchDashboardData = async () => {
    try {
      const { data: orders } = await supabase.from('orders').select('*').eq('customer_id', user.id).order('created_at', { ascending: false })
      const totalSpent = orders?.reduce((sum, o) => sum + parseFloat(o.total_amount || 0), 0) || 0
      const pendingCount = orders?.filter(o => o.status === 'pending' || o.status === 'processing').length || 0
      setStats({ totalOrders: orders?.length || 0, pendingOrders: pendingCount, totalSpent })
      setRecentOrders(orders?.slice(0, 3) || [])
    } finally { setLoading(false) }
  }

  if (loading) return <CustomerLayout><div className="text-center p-5"><div className="spinner-border text-primary" /></div></CustomerLayout>

  return (
    <CustomerLayout>
      <h2 className="mb-4">Welcome, {user?.full_name}!</h2>
      <div className="row g-4 mb-4">
        <div className="col-md-4"><div className="stat-card"><div className="d-flex justify-content-between align-items-center"><div><p className="mb-1 opacity-75">Total Orders</p><h3 className="mb-0">{stats.totalOrders}</h3></div><i className="bi bi-box-seam fs-1 opacity-50"></i></div></div></div>
        <div className="col-md-4"><div className="stat-card warning"><div className="d-flex justify-content-between align-items-center"><div><p className="mb-1 opacity-75">Pending</p><h3 className="mb-0">{stats.pendingOrders}</h3></div><i className="bi bi-hourglass-split fs-1 opacity-50"></i></div></div></div>
        <div className="col-md-4"><div className="stat-card success"><div className="d-flex justify-content-between align-items-center"><div><p className="mb-1 opacity-75">Total Spent</p><h3 className="mb-0">₹{stats.totalSpent.toFixed(2)}</h3></div><i className="bi bi-currency-rupee fs-1 opacity-50"></i></div></div></div>
      </div>
      <div className="row g-4 mb-4">
        <div className="col-md-4"><Link to="/products"><div className="dashboard-card d-flex align-items-center gap-3"><div className="bg-primary bg-opacity-10 rounded-circle p-3"><i className="bi bi-search fs-3 text-primary"></i></div><div><h5 className="mb-1">Browse Products</h5><p className="text-muted mb-0">Discover new products</p></div></div></Link></div>
        <div className="col-md-4"><Link to="/customer/orders"><div className="dashboard-card d-flex align-items-center gap-3"><div className="bg-success bg-opacity-10 rounded-circle p-3"><i className="bi bi-box-seam fs-3 text-success"></i></div><div><h5 className="mb-1">My Orders</h5><p className="text-muted mb-0">Track your orders</p></div></div></Link></div>
        <div className="col-md-4"><Link to="/customer/profile"><div className="dashboard-card d-flex align-items-center gap-3"><div className="bg-warning bg-opacity-10 rounded-circle p-3"><i className="bi bi-person fs-3 text-warning"></i></div><div><h5 className="mb-1">My Profile</h5><p className="text-muted mb-0">Manage account</p></div></div></Link></div>
      </div>
      <div className="dashboard-card">
        <div className="d-flex justify-content-between align-items-center mb-3"><h5 className="mb-0">Recent Orders</h5><Link to="/customer/orders" className="btn btn-sm btn-outline-primary">View All</Link></div>
        {recentOrders.length === 0 ? <div className="text-center py-4"><i className="bi bi-box-seam fs-1 d-block mb-2 text-muted"></i><p className="text-muted mb-3">No orders yet</p><Link to="/products" className="btn btn-primary"><i className="bi bi-cart3 me-2"></i>Start Shopping</Link></div> : <div className="list-group list-group-flush">{recentOrders.map(o => <div key={o.id} className="list-group-item d-flex justify-content-between align-items-center"><div><h6 className="mb-1">Order #{o.id.substring(0, 8)}</h6><small className="text-muted">{new Date(o.created_at).toLocaleDateString()} • {o.payment_method?.toUpperCase()}</small></div><div className="text-end"><p className="mb-0 fw-bold">₹{o.total_amount?.toFixed(2)}</p><span className={`badge-status badge-${o.status}`}>{o.status}</span></div></div>)}</div>}
      </div>
    </CustomerLayout>
  )
}

export default CustomerDashboard
