import React, { useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { toast } from 'react-toastify'
import CustomerLayout from '../../components/CustomerLayout'

const CustomerProfile = () => {
  const { user, updateCustomerProfile } = useAuth()
  const [form, setForm] = useState({ full_name: user?.full_name || '', phone: user?.phone || '', address: user?.address || '', city: user?.city || '', postal_code: user?.postal_code || '' })
  const [saving, setSaving] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault(); setSaving(true)
    try { await updateCustomerProfile(form); toast.success('Profile updated') } catch { toast.error('Failed') }
    finally { setSaving(false) }
  }

  return (
    <CustomerLayout>
      <h2 className="mb-4">My Profile</h2>
      <div className="row"><div className="col-md-8 col-lg-6">
        <div className="dashboard-card">
          <form onSubmit={handleSubmit}>
            <div className="row g-3">
              <div className="col-md-6"><label className="form-label">Email</label><input type="email" className="form-control" value={user?.email || ''} disabled /><small className="text-muted">Cannot be changed</small></div>
              <div className="col-md-6"><label className="form-label">Phone</label><input type="tel" className="form-control" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
              <div className="col-12"><label className="form-label">Full Name</label><input type="text" className="form-control" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} required /></div>
              <div className="col-12"><label className="form-label">Street Address</label><input type="text" className="form-control" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
              <div className="col-md-6"><label className="form-label">City</label><input type="text" className="form-control" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
              <div className="col-md-6"><label className="form-label">Postal Code</label><input type="text" className="form-control" value={form.postal_code} onChange={(e) => setForm({ ...form, postal_code: e.target.value })} /></div>
              <div className="col-12 mt-4"><button type="submit" className="btn btn-primary" disabled={saving}>{saving ? <><span className="spinner-border spinner-border-sm me-2"></span>Saving...</> : <><i className="bi bi-check me-2"></i>Save Changes</>}</button></div>
            </div>
          </form>
        </div>
      </div></div>
    </CustomerLayout>
  )
}

export default CustomerProfile
