import React, { Suspense, lazy } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import { CartProvider } from './context/CartContext'

import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import Products from './pages/Products'
import Cart from './pages/Cart'
import Navbar from './components/Navbar'

const ProductDetail = lazy(() => import('./pages/ProductDetail'))
const Checkout = lazy(() => import('./pages/Checkout'))
const OrderSuccess = lazy(() => import('./pages/OrderSuccess'))

const AdminDashboard = lazy(() => import('./pages/admin/AdminDashboard'))
const ManageVendors = lazy(() => import('./pages/admin/ManageVendors'))
const ManageCustomers = lazy(() => import('./pages/admin/ManageCustomers'))
const ManageCategories = lazy(() => import('./pages/admin/ManageCategories'))
const AllProducts = lazy(() => import('./pages/admin/AllProducts'))
const AllOrders = lazy(() => import('./pages/admin/AllOrders'))
const Reports = lazy(() => import('./pages/admin/Reports'))
const Settlements = lazy(() => import('./pages/admin/Settlements'))

const VendorDashboard = lazy(() => import('./pages/vendor/VendorDashboard'))
const VendorProducts = lazy(() => import('./pages/vendor/VendorProducts'))
const VendorOrders = lazy(() => import('./pages/vendor/VendorOrders'))
const VendorEarnings = lazy(() => import('./pages/vendor/VendorEarnings'))

const CustomerDashboard = lazy(() => import('./pages/customer/CustomerDashboard'))
const CustomerOrders = lazy(() => import('./pages/customer/CustomerOrders'))
const CustomerProfile = lazy(() => import('./pages/customer/CustomerProfile'))

const PageLoader = () => (
  <div className="text-center p-5">
    <div className="spinner-border text-primary" style={{ width: '2rem', height: '2rem' }} />
    <p className="text-muted mt-3">Loading...</p>
  </div>
)

const AdminRoute = ({ children }) => {
  const { user, userType, loading } = useAuth()
  if (loading) return <PageLoader />
  if (!user || userType !== 'admin') return <Navigate to="/login" />
  return children
}

const VendorRoute = ({ children }) => {
  const { user, userType, loading } = useAuth()
  if (loading) return <PageLoader />
  if (!user || userType !== 'vendor') return <Navigate to="/login" />
  return children
}

const CustomerRoute = ({ children }) => {
  const { user, userType, loading } = useAuth()
  if (loading) return <PageLoader />
  if (!user || userType !== 'customer') return <Navigate to="/login" />
  return children
}

const GuestRoute = ({ children }) => {
  const { user, userType, loading } = useAuth()
  if (loading) return <PageLoader />
  if (user && userType === 'admin') return <Navigate to="/admin" />
  if (user && userType === 'vendor') return <Navigate to="/vendor" />
  if (user && userType === 'customer') return <Navigate to="/customer" />
  return children
}

function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <Suspense fallback={<><Navbar /><PageLoader /></>}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/products" element={<Products />} />
            <Route path="/product/:id" element={<ProductDetail />} />
            <Route path="/login" element={<GuestRoute><Login /></GuestRoute>} />
            <Route path="/register" element={<GuestRoute><Register /></GuestRoute>} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/checkout" element={<CustomerRoute><Checkout /></CustomerRoute>} />
            <Route path="/order-success/:orderId" element={<CustomerRoute><OrderSuccess /></CustomerRoute>} />

            <Route path="/admin" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
            <Route path="/admin/vendors" element={<AdminRoute><ManageVendors /></AdminRoute>} />
            <Route path="/admin/customers" element={<AdminRoute><ManageCustomers /></AdminRoute>} />
            <Route path="/admin/categories" element={<AdminRoute><ManageCategories /></AdminRoute>} />
            <Route path="/admin/products" element={<AdminRoute><AllProducts /></AdminRoute>} />
            <Route path="/admin/orders" element={<AdminRoute><AllOrders /></AdminRoute>} />
            <Route path="/admin/reports" element={<AdminRoute><Reports /></AdminRoute>} />
            <Route path="/admin/settlements" element={<AdminRoute><Settlements /></AdminRoute>} />

            <Route path="/vendor" element={<VendorRoute><VendorDashboard /></VendorRoute>} />
            <Route path="/vendor/products" element={<VendorRoute><VendorProducts /></VendorRoute>} />
            <Route path="/vendor/orders" element={<VendorRoute><VendorOrders /></VendorRoute>} />
            <Route path="/vendor/earnings" element={<VendorRoute><VendorEarnings /></VendorRoute>} />

            <Route path="/customer" element={<CustomerRoute><CustomerDashboard /></CustomerRoute>} />
            <Route path="/customer/orders" element={<CustomerRoute><CustomerOrders /></CustomerRoute>} />
            <Route path="/customer/profile" element={<CustomerRoute><CustomerProfile /></CustomerRoute>} />

            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </Suspense>
      </CartProvider>
    </AuthProvider>
  )
}

export default App
