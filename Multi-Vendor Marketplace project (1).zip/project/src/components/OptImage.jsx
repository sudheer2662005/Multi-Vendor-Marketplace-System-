import React, { useState } from 'react'

const COLORS = {
  Electronics: '#dbeafe',
  Clothing: '#fce7f3',
  'Home & Garden': '#d1fae5',
  'Sports & Outdoors': '#fef3c7',
  Books: '#ede9fe',
}

const ICONS = {
  Electronics: '🎧',
  Clothing: '👕',
  'Home & Garden': '🏡',
  'Sports & Outdoors': '⚽',
  Books: '📚',
}

function makeSvgPlaceholder(text, color) {
  const bg = color || '#f1f5f9'
  const fill = '#475569'
  const lines = text.length > 20 ? [text.substring(0, 20), text.substring(20)] : [text]
  return `data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300"><rect width="400" height="300" fill="${bg}"/><text x="200" y="140" font-family="system-ui,sans-serif" font-size="16" fill="${fill}" text-anchor="middle" font-weight="600">${lines[0]}</text>${lines[1] ? `<text x="200" y="165" font-family="system-ui,sans-serif" font-size="16" fill="${fill}" text-anchor="middle" font-weight="600">${lines[1]}</text>` : ''}</svg>`)}`
}

const OptImage = ({ src, alt, style, className, category }) => {
  const [imgError, setImgError] = useState(false)

  const color = COLORS[category] || '#f1f5f9'
  const placeholder = makeSvgPlaceholder(alt || 'Product', color)

  if (imgError || !src) {
    return <img src={placeholder} alt={alt} style={style} className={className} />
  }

  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      onError={() => setImgError(true)}
      style={style}
      className={className}
    />
  )
}

export default OptImage
