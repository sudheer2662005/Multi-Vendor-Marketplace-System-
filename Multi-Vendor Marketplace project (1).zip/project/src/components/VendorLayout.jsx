import React from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const VendorLayout = ({ children }) => {
  const { user, logout } = useAuth()
  const location = useLocation()
  const navigate = useNavigate()

  const isActive = (path) => path === '/vendor' ? location.pathname === '/vendor' : location.pathname.startsWith(path)

  return (
    <div className="d-flex" style={{ minHeight: '100vh' }}>
      <div className="sidebar" style={{ width: '260px', position: 'sticky', top: 0, height: '100vh', overflowY: 'auto', backgroundColor: '#1e293b' }}>
        <div className="mb-4"><Link to="/" className="text-decoration-none"><h4 className="d-flex align-items-center gap-2 mb-1 text-white"><i className="bi bi-shop"></i>Marketplace</h4></Link><small className="text-muted">Vendor Panel</small></div>
        <hr className="border-secondary" />
        <nav className="nav flex-column">
          <Link to="/vendor" className={`nav-link text-white ${isActive('/vendor') && location.pathname === '/vendor' ? 'active bg-primary' : ''}`}><i className="bi bi-speedometer2 me-2"></i>Dashboard</Link>
          <Link to="/vendor/products" className={`nav-link text-white ${isActive('/vendor/products') ? 'active bg-primary' : ''}`}><i className="bi bi-box-seam me-2"></i>My Products</Link>
          <Link to="/vendor/orders" className={`nav-link text-white ${isActive('/vendor/orders') ? 'active bg-primary' : ''}`}><i className="bi bi-bag me-2"></i>Orders</Link>
          <Link to="/vendor/earnings" className={`nav-link text-white ${isActive('/vendor/earnings') ? 'active bg-primary' : ''}`}><i className="bi bi-wallet2 me-2"></i>Earnings</Link>
        </nav>
        <hr className="border-secondary" />
        <div className="mt-auto">
          <div className="d-flex align-items-center gap-2 mb-3"><div className="bg-primary rounded-circle p-2 text-white"><i className="bi bi-shop"></i></div><div><p className="mb-0 fw-semibold text-white">{user?.store_name}</p><small className="text-muted">{user?.email}</small></div></div>
          <button className="btn btn-outline-light w-100" onClick={() => { logout(); navigate('/') }}><i className="bi bi-box-arrow-left me-2"></i>Logout</button>
        </div>
      </div>
      <div className="flex-grow-1 p-4" style={{ backgroundColor: '#f1f5f9' }}>{children}</div>
    </div>
  )
}

export default VendorLayout
