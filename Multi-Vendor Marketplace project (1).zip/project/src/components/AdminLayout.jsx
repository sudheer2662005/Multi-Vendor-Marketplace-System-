import React from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const AdminLayout = ({ children }) => {
  const { user, logout } = useAuth()
  const location = useLocation()
  const navigate = useNavigate()

  const isActive = (path) => path === '/admin' ? location.pathname === '/admin' : location.pathname.startsWith(path)

  return (
    <div className="d-flex" style={{ minHeight: '100vh' }}>
      <div className="sidebar" style={{ width: '260px', position: 'sticky', top: 0, height: '100vh', overflowY: 'auto' }}>
        <div className="mb-4"><Link to="/" className="text-decoration-none"><h4 className="d-flex align-items-center gap-2 mb-1"><i className="bi bi-shop text-primary"></i>Marketplace</h4></Link><small className="text-muted">Admin Panel</small></div>
        <hr />
        <nav className="nav flex-column">
          <Link to="/admin" className={`nav-link ${isActive('/admin') && location.pathname === '/admin' ? 'active' : ''}`}><i className="bi bi-speedometer2 me-2"></i>Dashboard</Link>
          <Link to="/admin/vendors" className={`nav-link ${isActive('/admin/vendors') ? 'active' : ''}`}><i className="bi bi-shop me-2"></i>Manage Vendors</Link>
          <Link to="/admin/customers" className={`nav-link ${isActive('/admin/customers') ? 'active' : ''}`}><i className="bi bi-people me-2"></i>Manage Customers</Link>
          <Link to="/admin/categories" className={`nav-link ${isActive('/admin/categories') ? 'active' : ''}`}><i className="bi bi-tags me-2"></i>Categories</Link>
          <Link to="/admin/products" className={`nav-link ${isActive('/admin/products') ? 'active' : ''}`}><i className="bi bi-box-seam me-2"></i>All Products</Link>
          <Link to="/admin/orders" className={`nav-link ${isActive('/admin/orders') ? 'active' : ''}`}><i className="bi bi-bag me-2"></i>All Orders</Link>
          <Link to="/admin/reports" className={`nav-link ${isActive('/admin/reports') ? 'active' : ''}`}><i className="bi bi-graph-up me-2"></i>Reports</Link>
          <Link to="/admin/settlements" className={`nav-link ${isActive('/admin/settlements') ? 'active' : ''}`}><i className="bi bi-bank me-2"></i>Settlements</Link>
        </nav>
        <hr />
        <div className="mt-auto">
          <div className="d-flex align-items-center gap-2 mb-3"><div className="bg-primary rounded-circle p-2 text-white"><i className="bi bi-person-fill"></i></div><div><p className="mb-0 fw-semibold">{user?.full_name}</p><small className="text-muted">Administrator</small></div></div>
          <button className="btn btn-outline-danger w-100" onClick={() => { logout(); navigate('/') }}><i className="bi bi-box-arrow-left me-2"></i>Logout</button>
        </div>
      </div>
      <div className="flex-grow-1 p-4" style={{ backgroundColor: '#f1f5f9' }}>{children}</div>
    </div>
  )
}

export default AdminLayout
