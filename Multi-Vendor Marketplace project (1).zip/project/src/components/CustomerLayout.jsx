import React from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'

const CustomerLayout = ({ children }) => {
  const { user, logout } = useAuth()
  const { getCartCount } = useCart()
  const location = useLocation()
  const navigate = useNavigate()

  const isActive = (path) => location.pathname === path

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <nav className="navbar navbar-expand-lg sticky-top" style={{ backgroundColor: '#1e293b' }}>
        <div className="container">
          <Link className="navbar-brand text-white" to="/"><i className="bi bi-shop me-2"></i>Marketplace</Link>
          <div className="d-flex align-items-center gap-3">
            <Link to="/products" className="btn btn-outline-light btn-sm"><i className="bi bi-search me-1"></i>Browse</Link>
            <Link to="/cart" className="btn btn-outline-light position-relative"><i className="bi bi-cart3"></i>{getCartCount() > 0 && <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">{getCartCount()}</span>}</Link>
            <div className="dropdown">
              <button className="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown"><i className="bi bi-person-circle me-2"></i>{user?.full_name}</button>
              <ul className="dropdown-menu dropdown-menu-end">
                <li><Link className="dropdown-item" to="/customer"><i className="bi bi-speedometer2 me-2"></i>Dashboard</Link></li>
                <li><Link className="dropdown-item" to="/customer/orders"><i className="bi bi-box-seam me-2"></i>My Orders</Link></li>
                <li><Link className="dropdown-item" to="/customer/profile"><i className="bi bi-person me-2"></i>Profile</Link></li>
                <li><hr className="dropdown-divider" /></li>
                <li><button className="dropdown-item" onClick={() => { logout(); navigate('/'); }}><i className="bi bi-box-arrow-right me-2"></i>Logout</button></li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
      <div className="flex-grow-1" style={{ backgroundColor: '#f1f5f9' }}>
        <div className="container py-4">
          <div className="row mb-4">
            <div className="col-12">
              <div className="d-flex gap-2 flex-wrap">
                <Link to="/customer" className={`btn ${isActive('/customer') ? 'btn-primary' : 'btn-outline-primary'}`}><i className="bi bi-speedometer2 me-2"></i>Dashboard</Link>
                <Link to="/customer/orders" className={`btn ${isActive('/customer/orders') ? 'btn-primary' : 'btn-outline-primary'}`}><i className="bi bi-box-seam me-2"></i>My Orders</Link>
                <Link to="/customer/profile" className={`btn ${isActive('/customer/profile') ? 'btn-primary' : 'btn-outline-primary'}`}><i className="bi bi-person me-2"></i>Profile</Link>
              </div>
            </div>
          </div>
          {children}
        </div>
      </div>
      <footer className="bg-dark text-white py-4 mt-auto"><div className="container text-center"><p className="mb-0">© 2024 Multi-Vendor Marketplace. All rights reserved.</p></div></footer>
    </div>
  )
}

export default CustomerLayout
