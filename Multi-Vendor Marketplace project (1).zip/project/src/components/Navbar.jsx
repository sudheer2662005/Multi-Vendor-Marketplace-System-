import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'

const Navbar = () => {
  const { user, userType, logout } = useAuth()
  const { getCartCount } = useCart()
  const navigate = useNavigate()

  const handleLogout = () => { logout(); navigate('/') }
  const getDashboardLink = () => {
    if (userType === 'admin') return '/admin'
    if (userType === 'vendor') return '/vendor'
    if (userType === 'customer') return '/customer'
    return '/'
  }

  return (
    <nav className="navbar navbar-expand-lg sticky-top">
      <div className="container">
        <Link className="navbar-brand" to="/"><i className="bi bi-shop me-2"></i>Marketplace</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"><span className="navbar-toggler-icon"></span></button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav mx-auto">
            <li className="nav-item"><Link className="nav-link" to="/">Home</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/products">Products</Link></li>
          </ul>
          <div className="d-flex align-items-center gap-3">
            {user ? (
              <>
                <Link to="/cart" className="btn btn-outline-primary position-relative">
                  <i className="bi bi-cart3"></i>
                  {getCartCount() > 0 && userType === 'customer' && <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">{getCartCount()}</span>}
                </Link>
                <div className="dropdown">
                  <button className="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown"><i className="bi bi-person-circle me-2"></i>{user.full_name || user.store_name || user.email}</button>
                  <ul className="dropdown-menu dropdown-menu-end">
                    <li><Link className="dropdown-item" to={getDashboardLink()}><i className="bi bi-speedometer2 me-2"></i>Dashboard</Link></li>
                    {userType === 'customer' && (<><li><Link className="dropdown-item" to="/customer/orders"><i className="bi bi-box me-2"></i>My Orders</Link></li><li><Link className="dropdown-item" to="/customer/profile"><i className="bi bi-person me-2"></i>Profile</Link></li></>)}
                    <li><hr className="dropdown-divider" /></li>
                    <li><button className="dropdown-item" onClick={handleLogout}><i className="bi bi-box-arrow-right me-2"></i>Logout</button></li>
                  </ul>
                </div>
              </>
            ) : (<><Link to="/cart" className="btn btn-outline-primary"><i className="bi bi-cart3"></i></Link><Link to="/login" className="btn btn-outline-primary">Login</Link><Link to="/register" className="btn btn-primary">Register</Link></>)}
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navbar
